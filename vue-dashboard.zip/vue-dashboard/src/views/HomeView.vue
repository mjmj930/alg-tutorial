<template>
    <el-card class="shadow-sm rounded-lg">
      <template #header>
        <el-button @click="toggleData">
          {{ showUplink ? '显示下行数据' : '显示上行数据' }}
        </el-button>
      </template>
      <RsrpChart :showUplink="showUplink" />
      <ThrpChart :showUplink="showUplink" />
    </el-card>
  </template>
  
  <script setup lang="ts">
  import RsrpChart from '../components/RsrpChart.vue'
  import ThrpChart from '../components/ThrpChart.vue'
  import { ref } from 'vue'
  import eventBus from '../utils/eventBus'
  
  const showUplink = ref(true)
  
  const toggleData = () => {
    showUplink.value = !showUplink.value
    eventBus.emit('toggleDataDisplay', showUplink.value) // 触发事件
  }
  </script>
  
  <style scoped>
  :deep(.el-card) {
    transition: all 0.3s ease;
  }
  
  :deep(.el-card):hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
  }
  </style>