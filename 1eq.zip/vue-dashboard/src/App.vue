<!-- src/App.vue -->
<template>
  <DashboardLayout>
    <!-- 左侧栏内容 -->
    <template #sidebar>
      <UeSidebar />
      <!-- 或者对于基站级数据展示，可以使用 BsSidebar -->
      <!-- <BsSidebar /> -->
    </template>

    <!-- 底部栏内容 -->
    <template #bottom-bar>
      <UserDashboardCharts />
      <!-- 或者对于基站级数据展示，可以使用 BsDashboardCharts -->
      <!-- <BsDashboardCharts /> -->
    </template>
  </DashboardLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import DashboardLayout from '@/components/layouts/Layout.vue';
import UeSidebar from '@/components/common/UeSideBar.vue';
import UserDashboardCharts from '@/components/common/UeBottomBar.vue';
import DataTables from './views/DataTables.vue'

export default defineComponent({
  name: 'App',
  components: {
    DashboardLayout,
    UeSidebar,
    UserDashboardCharts,
    DataTables,
    // BsSidebar,
    // BsDashboardCharts,
  },
});
</script>

<style>
/* 可以在这里添加全局样式 */
</style>
