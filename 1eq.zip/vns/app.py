from flask import Flask
from socket_events import socketio, start_sending_data

# 创建 Flask 实例
app = Flask(__name__)

# 初始化 Socket.IO
socketio.init_app(app, cors_allowed_origins="*")

# 启动数据发送线程
start_sending_data()

# 设置一个简单的根路由
@app.route("/")
def index():
    return "Socket.IO Server is Running!"

# 启动 Flask 应用
if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)