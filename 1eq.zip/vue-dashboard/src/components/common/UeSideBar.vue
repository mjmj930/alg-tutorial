<template>
  <div>
    <!-- 标题 -->
    <div class="header-section">
      <h2>用户级数据展示</h2>
      <h3>test</h3>
    </div>

    <!-- 数据展示区 -->
    <div class="data-section">
      <!-- MCS 卡片 -->
      <DataCard
        v-if="activeCard.mcs === 'ul'"
        id="ul_mcs"
        title="UL MCS"
        :value="ueData.ul_mcs"
        interactive
        @toggle="switchCard('mcs')"
      />
      <DataCard
        v-else
        id="dl_mcs"
        title="DL MCS"
        :value="ueData.dl_mcs"
        interactive
        @toggle="switchCard('mcs')"
      />

      <!-- BLER 卡片 -->
      <DataCard
        v-if="activeCard.bler === 'ul'"
        id="ul_bler"
        title="UL BLER"
        :value="`${ueData.ul_bler} %`"
        interactive
        @toggle="switchCard('bler')"
      />
      <DataCard
        v-else
        id="dl_bler"
        title="DL BLER"
        :value="`${ueData.dl_bler} %`"
        interactive
        @toggle="switchCard('bler')"
      />

      <!-- 静态数据卡片 -->
      <DataCard
        id="dl_mimo_rank"
        title="DL MIMO RANK"
        :value="ueData.dl_mimo_rank"
        :interactive="false"
      />
      <DataCard
        id="uplink_ssb_rank"
        title="UL SSB RANK"
        :value="ueData.uplink_ssb_rank"
        :interactive="false"
      />
      <DataCard
        id="csi_sinr"
        title="CSI SINR"
        :value="`${ueData.csi_sinr} dB`"
        :interactive="false"
      />
      <DataCard
        id="dmrs_sinr"
        title="DMRS SINR"
        :value="`${ueData.dmrs_sinr} dB`"
        :interactive="false"
      />
            <!-- 显示 GPS 数据 -->
      <!-- <DataCard
        id="gps"
        title="GPS"
        :value="`Lat: ${ueData.gps.latitude}, Lon: ${ueData.gps.longitude}`"
        :interactive="false"
      /> -->
    </div>
  </div>
  <UeGaugeChart/>
  
</template>

<script lang="ts">
import { defineComponent, ref, computed } from "vue";
import { useDataService } from "@/services/service"; // 引入数据服务模拟
import DataCard from "@/components/widgets/DataCard.vue";
import UeGaugeChart from "@/components/charts/UeGaugeChart.vue";


// 默认 UE 数据
const defaultUeData = {
  ul_mcs: 0,
  dl_mcs: 0,
  dl_mimo_rank: 0,
  dl_bler: 0,
  ul_bler: 0,
  uplink_ssb_rank: 0,
  csi_sinr: 0,
  dmrs_sinr: 0,
};

export default defineComponent({
  name: "UeDashboardSidebar",
  components: {
    DataCard,
    UeGaugeChart,
  },
  setup() {
    const { latestData } = useDataService(); // 获取数据服务

    // 当前显示的卡片状态
    const activeCard = ref({
      mcs: "ul", // 初始显示 UL MCS
      bler: "ul", // 初始显示 UL BLER
    });

    // 切换卡片逻辑
    const switchCard = (id: keyof typeof activeCard.value) => {
      activeCard.value[id] = activeCard.value[id] === "ul" ? "dl" : "ul";
    };

    // 计算用户数据（如果为空，返回默认值）
    const ueData = computed(() => latestData.value?.data.ueData || defaultUeData);

    return {
      activeCard,
      switchCard,
      ueData,
    };
  },
});
</script>

<style scoped>
.header-section {
  text-align: center;
  margin-top: 1%;
  margin-bottom: 20px;
  font-size: 18px;
}

.data-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 20px;
}
</style>