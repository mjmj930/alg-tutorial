<template>
  <div class="device-list-container p-6">
    <h2 class="text-2xl font-bold mb-6">设备网络监控</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <DeviceCard 
        v-for="device in deviceList" 
        :key="device.id" 
        :device="device"
        @click="handleDeviceClick(device.id)"
      />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { useDevicesStore } from '@/stores/devices'
import { useRouter } from 'vue-router'
import DeviceCard from './DeviceCard.vue'
import { emitDeviceSelect } from '@/utils/eventmitt'

const router = useRouter()
const devicesStore = useDevicesStore()
const deviceList = ref(devicesStore.devices)

// 加载设备数据
onMounted(() => {
  devicesStore.fetchDevices()
  deviceList.value = devicesStore.devices
})

// 处理设备点击事件
const handleDeviceClick = (deviceId: string) => {
  emitDeviceSelect(deviceId)
  router.push({ name: 'DeviceDetail', params: { id: deviceId } })
}
</script>  