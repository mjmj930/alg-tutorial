<!-- src/components/common/Footer.vue -->
<template>
    <el-footer class="footer">
      <div class="footer-content">© gaifu224@foxmail.com</div>
    </el-footer>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Footer',
  });
  </script>
  
  <style scoped>
  .footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    height: 40px;
    line-height: 40px;
  }
  .footer-content {
    font-size: 14px;
  }
  </style>