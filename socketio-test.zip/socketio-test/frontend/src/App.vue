<!-- src/App.vue -->
<template>
  <div id="app">
    <DataTables />
  </div>
</template>
<script lang="ts" setup>

import DataTables from './components/DataTables.vue'
</script>

<style>
body {
  background-color: #f5f5f5;
}
</style>