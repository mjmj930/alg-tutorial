# storage.py

import json
import os
import threading

class JSONStorage:
    """
    用于将数据存储到本地 JSON 文件的简单工具类。
    """
    _lock = threading.Lock()

    def __init__(self, filepath="data.json"):
        self.filepath = filepath
        # 如果文件不存在，初始化一个空[]或{}之类的结构
        if not os.path.exists(self.filepath):
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump([], f)

    def save_record(self, record: dict):
        """
        添加一条记录到JSON文件
        """
        with self._lock:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                data = []

            data.append(record)
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)

    def load_all(self):
        """
        读取所有记录
        """
        with self._lock:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []