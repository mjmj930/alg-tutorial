<template>
    <div class="app-layout">
      <Sidebar />
      <div class="main-content">
        <router-view />
        <BottomBar />
      </div>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue'
  import Sidebar from './Sidebar.vue'
  import BottomBar from './BottomBar.vue'
  
  export default defineComponent({
    name: 'AppLayout',
    components: {
      Sidebar,
      BottomBar
    }
  })
  </script>
  
  <style scoped>
  .app-layout {
    display: flex;
    min-height: 100vh;
    background-color: #0f1621;
    color: #e0e0e0;
  }
  
  .main-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding-left: 250px; /* 侧边栏宽度 */
    transition: padding-left 0.3s;
  }
  
  @media (max-width: 992px) {
    .main-content {
      padding-left: 0;
    }
  }
  </style>