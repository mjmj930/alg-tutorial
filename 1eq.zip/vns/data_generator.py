import random

# 模拟 UE 数据生成
def generate_ue_data():
    return {
        "ul_mcs": random.randint(0, 28),
        "dl_mcs": random.randint(0, 28),
        "dl_mimo_rank": random.randint(1, 4),
        "dl_bler": round(random.uniform(0, 10), 2),  # 百分比
        "ul_bler": round(random.uniform(0, 10), 2),  # 百分比
        "ul_throughput": round(random.uniform(1, 100), 2),  # Mbps
        "dl_throughput": round(random.uniform(1, 200), 2),  # Mbps
        "downlink_rsrp": random.randint(-120, -60),  # dBm
        "uplink_ssb_rank": random.randint(1, 4),
        "csi_sinr": random.randint(-5, 30),  # dB
        "dmrs_sinr": random.randint(-5, 30),  # dB
        "gps": {
            "latitude": round(random.uniform(-90, 90), 6),
            "longitude": round(random.uniform(-180, 180), 6),
        },
    }

# 模拟 BS 数据生成
def generate_bs_data():
    return {
        "dl_rlc_throughput": round(random.uniform(100, 1000), 2),  # Mbps
        "ul_rlc_throughput": round(random.uniform(50, 500), 2),  # Mbps
        "general_user_number": random.randint(1, 100),
        "dl_used_rb_num": random.randint(1, 100),
        "ul_used_rb_num": random.randint(1, 100),
        "downlink_stream_num": random.randint(1, 16),
        "uplink_stream_num": random.randint(1, 16),
        "dl_pdsch_ack_num": {
            "Code0": random.randint(0, 100),
            "Code1": random.randint(0, 100),
            "Code2": random.randint(0, 100),
            "Code3": random.randint(0, 100),
        },
        "dl_pdsch_nack_num": {
            "Code0": random.randint(0, 100),
            "Code1": random.randint(0, 100),
            "Code2": random.randint(0, 100),
            "Code3": random.randint(0, 100),
        },
        "ul_pdsch_dtx_num": {
            "Code0": random.randint(0, 100),
            "Code1": random.randint(0, 100),
            "Code2": random.randint(0, 100),
            "Code3": random.randint(0, 100),
        },
    }