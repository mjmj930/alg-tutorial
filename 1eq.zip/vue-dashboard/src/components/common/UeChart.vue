<!-- src/views/UserDashboard/components/UeChart.vue -->
<template>
    <LineChart
      title="用户特定数据"
      :xData="xData"
      :yData="yData"
      color="#ff6347"
    />
  </template>

  <script lang="ts">
  import { defineComponent, computed } from 'vue';
  import LineChart from '@/components/charts/ULThroughputChart.vue';
  import { useUeStore } from '@/store/modules/ueModuleule';

  export default defineComponent({
    name: 'UserSpecificChart',
    components: {
      LineChart,
    },
    setup() {
      const userStore = useUeStore();

      const xData = computed(() => userStore.rlcTime);
      const yData = computed(() => userStore.downlinkRLC);

      return {
        xData,
        yData,
      };
    },
  });
  </script>

  <style scoped>
  /* 根据需要添加样式 */
  </style>
