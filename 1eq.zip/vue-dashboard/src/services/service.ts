import { ref } from 'vue';
import { io, Socket } from 'socket.io-client';

// 定义 UE 数据类型
export type UeDataItem = {
  ul_mcs: number;
  dl_mcs: number;
  dl_mimo_rank: number;
  dl_bler: number;
  ul_bler: number;
  ul_throughput: number;
  dl_throughput: number;
  downlink_rsrp: number;
  uplink_ssb_rank: number;
  csi_sinr: number;
  dmrs_sinr: number;
  gps: {
    latitude: number;
    longitude: number;
  };
};

// 定义 BS 数据类型
export type BsDataItem = {
  dl_rlc_throughput: number;          // DL RLC 吞吐量
  ul_rlc_throughput: number;          // UL RLC 吞吐量
  general_user_number: number;        // 用户总数
  dl_used_rb_num: number;             // DL 已用 RB 数量
  ul_used_rb_num: number;             // UL 已用 RB 数量
  downlink_stream_num: number;        // 下行流数量
  uplink_stream_num: number;          // 上行流数量
  dl_pdsch_ack_num: {
    Code0: number;
    Code1: number;
    Code2: number;
    Code3: number;
  }; // DL PDSCH Code ACK 数量
  dl_pdsch_nack_num: {
    Code0: number;
    Code1: number;
    Code2: number;
    Code3: number;
  }; // DL PUSCH Code NACK 数量
  ul_pdsch_dtx_num: {
    Code0: number;
    Code1: number;
    Code2: number;
    Code3: number;
  }; // UL PDSCH Code DTX 数量
};

// 定义数据存储的结构
export type DataPayload = {
  timestamp: string; // 时间戳
  data: {
    ueData: UeDataItem; // UE 数据
    bsData: BsDataItem; // BS 数据
  };
};

// 创建一个 Socket.IO 客户端
const socket: Socket = io('http://localhost:5000'); // 后端地址

// 创建响应式变量，用于存储数据
const latestData = ref<DataPayload | null>(null);

// 监听后端数据更新
socket.on('update_data', (payload: DataPayload) => {
  latestData.value = payload; // 更新数据
});

// 导出一个函数，用于在其他组件中获取数据
export function useDataService() {
  return {
    latestData, // 响应式数据
    socket      // 如果需要手动发消息，可以暴露 socket
  };
}