<template>
    <div class="dashboard-container">
      <div class="dashboard-title">
        <h1>网络性能监控仪表盘</h1>
      </div>
      
      <div class="status-bar">
        <div class="status-item">
          <div class="status-label">上行吞吐量</div>
          <div class="status-value">{{ currentData.uplink.toFixed(1) }} Mbps</div>
        </div>
        <div class="status-item">
          <div class="status-label">下行吞吐量</div>
          <div class="status-value">{{ currentData.downlink.toFixed(1) }} Mbps</div>
        </div>
        <div class="status-item">
          <div class="status-label">DL RSRP</div>
          <div class="status-value">{{ currentData.rsrp }} dBm</div>
        </div>
      </div>
      
      <div class="charts-container">
        <div class="chart-box">
          <div class="chart-title">
            <i>📤</i> 上行吞吐量 (Mbps)
          </div>
          <div ref="uplinkChart" class="chart"></div>
        </div>
        
        <div class="chart-box">
          <div class="chart-title">
            <i>📥</i> 下行吞吐量 (Mbps)
          </div>
          <div ref="downlinkChart" class="chart"></div>
        </div>
        
        <div class="chart-box">
          <div class="chart-title">
            <i>📶</i> DL RSRP (dBm)
          </div>
          <div ref="rsrpChart" class="chart"></div>
        </div>
      </div>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, ref, watch } from 'vue'
  import * as echarts from 'echarts'
  import { useNetworkStore } from '../stores/networkStore'
  import { storeToRefs } from 'pinia'
  
  export default defineComponent({
    name: 'NetworkDashboard',
    setup() {
      const networkStore = useNetworkStore()
      const { dataHistory, currentData } = storeToRefs(networkStore)
      
      const uplinkChart = ref<HTMLElement | null>(null)
      const downlinkChart = ref<HTMLElement | null>(null)
      const rsrpChart = ref<HTMLElement | null>(null)
      
      let uplinkInstance: echarts.ECharts | null = null
      let downlinkInstance: echarts.ECharts | null = null
      let rsrpInstance: echarts.ECharts | null = null
      
      const initCharts = () => {
        if (uplinkChart.value && downlinkChart.value && rsrpChart.value) {
          uplinkInstance = echarts.init(uplinkChart.value)
          downlinkInstance = echarts.init(downlinkChart.value)
          rsrpInstance = echarts.init(rsrpChart.value)
          
          updateCharts()
        }
      }
      
      const updateCharts = () => {
        if (!uplinkInstance || !downlinkInstance || !rsrpInstance) return
        
        const timestamps = dataHistory.value.map(item => item.timestamp)
        const uplinkData = dataHistory.value.map(item => item.uplink)
        const downlinkData = dataHistory.value.map(item => item.downlink)
        const rsrpData = dataHistory.value.map(item => item.rsrp)
        
        // 上行吞吐量图表配置
        const uplinkOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0} Mbps',
            axisPointer: {
              type: 'shadow',
              shadowStyle: {
                color: 'rgba(79, 172, 254, 0.2)'
              }
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          yAxis: {
            type: 'value',
            name: 'Mbps',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          series: [{
            name: '上行吞吐量',
            type: 'line',
            smooth: true,
            data: uplinkData,
            symbol: 'circle',
            symbolSize: 6,
            lineStyle: {
              width: 3,
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#00f2fe' },
                { offset: 1, color: '#4facfe' }
              ])
            },
            itemStyle: {
              color: '#4facfe',
              borderColor: '#fff',
              borderWidth: 1
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(0, 242, 254, 0.3)' },
                { offset: 1, color: 'rgba(79, 172, 254, 0.1)' }
              ])
            }
          }]
        }
        
        // 下行吞吐量图表配置
        const downlinkOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0} Mbps',
            axisPointer: {
              type: 'shadow',
              shadowStyle: {
                color: 'rgba(79, 172, 254, 0.2)'
              }
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          yAxis: {
            type: 'value',
            name: 'Mbps',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          series: [{
            name: '下行吞吐量',
            type: 'line',
            smooth: true,
            data: downlinkData,
            symbol: 'circle',
            symbolSize: 6,
            lineStyle: {
              width: 3,
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#4facfe' },
                { offset: 1, color: '#00f2fe' }
              ])
            },
            itemStyle: {
              color: '#00f2fe',
              borderColor: '#fff',
              borderWidth: 1
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(79, 172, 254, 0.3)' },
                { offset: 1, color: 'rgba(0, 242, 254, 0.1)' }
              ])
            }
          }]
        }
        
        // RSRP图表配置
        const rsrpOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0} dBm',
            axisPointer: {
              type: 'shadow',
              shadowStyle: {
                color: 'rgba(79, 172, 254, 0.2)'
              }
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          yAxis: {
            type: 'value',
            name: 'dBm',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          visualMap: {
            show: false,
            dimension: 1,
            pieces: [
              { gt: -85, lte: -60, color: '#52c41a' }, // 优秀
              { gt: -95, lte: -85, color: '#faad14' }, // 良好
              { gt: -105, lte: -95, color: '#fa8c16' }, // 一般
              { gt: -115, lte: -105, color: '#f5222d' }, // 差
              { lte: -115, color: '#a8071a' } // 极差
            ]
          },
          series: [{
            name: 'DL RSRP',
            type: 'line',
            smooth: true,
            data: rsrpData,
            symbol: 'circle',
            symbolSize: 6,
            lineStyle: {
              width: 3
            },
            itemStyle: {
              borderColor: '#fff',
              borderWidth: 1
            },
            markArea: {
              silent: true,
              data: [
                [{
                  yAxis: -60,
                  itemStyle: {
                    color: 'rgba(82, 196, 26, 0.1)'
                  }
                }, {
                  yAxis: -85
                }],
                [{
                  yAxis: -85,
                  itemStyle: {
                    color: 'rgba(250, 173, 20, 0.1)'
                  }
                }, {
                  yAxis: -95
                }],
                [{
                  yAxis: -95,
                  itemStyle: {
                    color: 'rgba(250, 140, 22, 0.1)'
                  }
                }, {
                  yAxis: -105
                }],
                [{
                  yAxis: -105,
                  itemStyle: {
                    color: 'rgba(245, 34, 45, 0.1)'
                  }
                }, {
                  yAxis: -115
                }],
                [{
                  yAxis: -115,
                  itemStyle: {
                    color: 'rgba(168, 7, 26, 0.1)'
                  }
                }, {
                  yAxis: -140
                }]
              ]
            }
          }]
        }
        
        uplinkInstance.setOption(uplinkOption)
        downlinkInstance.setOption(downlinkOption)
        rsrpInstance.setOption(rsrpOption)
      }
      
      const handleResize = () => {
        if (uplinkInstance) uplinkInstance.resize()
        if (downlinkInstance) downlinkInstance.resize()
        if (rsrpInstance) rsrpInstance.resize()
      }
      
      onMounted(() => {
        initCharts()
        window.addEventListener('resize', handleResize)
      })
      
      return {
        uplinkChart,
        downlinkChart,
        rsrpChart,
        currentData
      }
    }
  })
  </script>
  
  <style scoped>
  .dashboard-container {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
  }
  
  .dashboard-title {
    text-align: center;
    margin-bottom: 30px;
    position: relative;
  }
  
  .dashboard-title h1 {
    font-size: 2.5rem;
    margin: 0;
    background: linear-gradient(90deg, #00f2fe, #4facfe);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    text-shadow: 0 0 10px rgba(79, 172, 254, 0.3);
  }
  
  .dashboard-title::after {
    content: '';
    display: block;
    width: 100px;
    height: 3px;
    background: linear-gradient(90deg, #00f2fe, #4facfe);
    margin: 10px auto;
    border-radius: 3px;
  }
  
  .charts-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
  }
  
  .chart-box {
    background: rgba(16, 31, 63, 0.7);
    border-radius: 10px;
    padding: 15px;
    box-shadow: 0 0 20px rgba(0, 242, 254, 0.1);
    border: 1px solid rgba(79, 172, 254, 0.2);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
  }
  
  .chart-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 242, 254, 0.2);
  }
  
  .chart-box::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(0, 242, 254, 0.1) 0%, rgba(79, 172, 254, 0.1) 100%);
    z-index: 0;
  }
  
  .chart-title {
    font-size: 1.2rem;
    margin-bottom: 15px;
    color: #4facfe;
    display: flex;
    align-items: center;
  }
  
  .chart-title i {
    margin-right: 10px;
    font-size: 1.5rem;
  }
  
  .chart {
    width: 100%;
    height: 300px;
    position: relative;
    z-index: 1;
  }
  
  .status-bar {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    padding: 10px 20px;
    background: rgba(16, 31, 63, 0.7);
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
  }
  
  .status-item {
    text-align: center;
  }
  
  .status-value {
    font-size: 1.5rem;
    font-weight: bold;
    margin: 5px 0;
    background: linear-gradient(90deg, #00f2fe, #4facfe);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  
  .status-label {
    font-size: 0.9rem;
    color: #8a9bb8;
  }
  
  @media (max-width: 768px) {
    .charts-container {
      grid-template-columns: 1fr;
    }
    
    .status-bar {
      flex-direction: column;
      gap: 15px;
    }
  }
  </style>