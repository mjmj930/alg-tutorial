// src/composables/useFetch.ts
import { ref } from 'vue';
import { AxiosResponse } from 'axios';
import { getUserData, getBsData } from '@/services/api';

export function useFetch() {
  const data = ref(null);
  const error = ref(null);
  const loading = ref(false);

  const fetchUserData = async () => {
    loading.value = true;
    try {
      const response: AxiosResponse = await getUserData();
      data.value = response.data;
    } catch (err) {
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  const fetchBsData = async () => {
    loading.value = true;
    try {
      const response: AxiosResponse = await getBsData();
      data.value = response.data;
    } catch (err) {
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  return {
    data,
    error,
    loading,
    fetchUserData,
    fetchBsData,
  };
}