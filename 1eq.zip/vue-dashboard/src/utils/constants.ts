// src/utils/constants.ts
export const MAX_DATA_POINTS = 10;

export const SOCKET_EVENTS = {
  USER_DATA: 'ue-data',
  BS_DATA: 'bs-data',
};