from construct import Struct, Byte, Int32ub, Float32b, Bytes

# ----------------- 协议头 -----------------
APP_MSG_HEADER = Struct(
    "magicnumber" / Byte,  # 1字节
    "MsgLen" / Byte  # 1字节
)

# ----------------- 消息体类型映射 -----------------
MESSAGE_BODY_STRUCTS = {
    # 握手协议 (0x1001)
    0x1001: Struct("HandshakeReq",
                   "version" / Int32ub
                   ),
    0x1002: Struct("HandshakeRsp",
                   "status" / Int32ub
                   ),

    # 心跳协议 (0x2001)
    0x2001: Struct("HeartbeatReq",
                   "timestamp" / Int32ub
                   ),
    0x2002: Struct("HeartbeatRsp",
                   "server_ts" / Int32ub
                   ),

    # 路测数据 (0x4001)
    0x4001: Struct("RoadTestData",
                   "speed" / Float32b,
                   "rpm" / Int32ub,
                   "voltage" / Float32b
                   )
}

# 自定义消息结构体
Metric1 = Struct(
    "APP_MSG_HEADER" / APP_MSG_HEADER,
    "MsgId" / Int32ub,
    "value1" / Float32b,
    "value2" / Int32ub
)