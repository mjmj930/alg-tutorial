// src/store/modules/bsModule.ts
import { defineStore } from 'pinia';
import { MAX_DATA_POINTS } from '@/utils/constants';

interface BsDataItem {
  id: string;
  title: string;
  value: string | number;
  unit: string;
}

export const useBsStore = defineStore('bs', {
  state: () => ({
    dataItems: [
      { id: 'peak-rate', title: 'Peak Rate', value: '0', unit: 'Mbps' },
      { id: 'user-rank', title: '实时用户 Rank', value: 0 },
      { id: 'mcs', title: 'MCS', value: 0 },
      { id: 'bler', title: 'BLER', value: '0%' },
      { id: 'rsrp', title: 'RSRP', value: '-50 dBm' },
      { id: 'snr', title: 'SNR', value: '20 dB' },
      { id: 'speed', title: '速度', value: '0 km/h' },
    ] as BsDataItem[],
    rsrp: -50,
    rlctime: [] as string[],
    downlinkRLC: [] as number[],
    uplinkRLC: [] as number[],
  }),
  actions: {
    // 更新数据项
    updateDataItems(data: any) {
      this.dataItems.forEach((item) => {
        if (data.hasOwnProperty(item.id)) {
          item.value = data[item.id];
        }
      });
      this.rsrp = parseFloat(data.rsrp);
    },
    // 添加RLC时间点
    addRLCTime(time: string) {
      this.rlctime.push(time);
      if (this.rlctime.length > MAX_DATA_POINTS) {
        this.rlctime.shift();
      }
    },
    // 添加下行RLC数据
    addDownlinkRLC(value: number) {
      this.downlinkRLC.push(value);
      if (this.downlinkRLC.length > MAX_DATA_POINTS) {
        this.downlinkRLC.shift();
      }
    },
    // 添加上行RLC数据
    addUplinkRLC(value: number) {
      this.uplinkRLC.push(value);
      if (this.uplinkRLC.length > MAX_DATA_POINTS) {
        this.uplinkRLC.shift();
      }
    },
  },
});
