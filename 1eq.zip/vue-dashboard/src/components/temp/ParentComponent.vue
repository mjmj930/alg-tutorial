<template>
    <div class="p-4">
      <h1 class="text-xl font-bold">实时数据</h1>
      <!-- 检查数据是否可用 -->
      <div v-if="latestData">
        <p><strong>时间戳:</strong> {{ latestData.timestamp }}</p>
        <p><strong>UL MCS:</strong> {{ latestData.data.ueData.ul_mcs }}</p>
        <p><strong>DL MCS:</strong> {{ latestData.data.ueData.dl_mcs }}</p>
        <p><strong>General User Number:</strong> {{ latestData.data.bsData.general_user_number }}</p>
        <!-- 将数据传递给子组件 -->
        <ChildComponent :ue-data="latestData.data.ueData" :bs-data="latestData.data.bsData" />
      </div>
      <div v-else>
        <p>数据加载中...</p>
      </div>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue';
  import { useDataService } from '@/services/DataService';
  import ChildComponent from './ChildComponent.vue';
  
  export default defineComponent({
    name: 'ParentComponent',
    components: {
      ChildComponent
    },
    setup() {
      // 使用数据服务
      const { latestData } = useDataService();
      return {
        latestData
      };
    }
  });
  </script>
  
  <style scoped>
  /* 添加样式 */
  </style>