import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router';
import UserDashboard from '@/views/UeDashboard.vue';
import BsDashboard from '@/views/BsDashboard.vue';
import DataTables from "@/views/DataTables.vue";

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: '/datatables', // 默认重定向到 /bs
  },
  {
    path: '/ue',
    name: 'UserDashboard',
    component: UserDashboard, // 用户面板
  },
  {
    path: '/bs',
    name: 'BsDashboard',
    component: BsDashboard, // 基站面板
  },
  {
    path: '/datatables',
    name: 'DataTables',
    component: DataTables,
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
