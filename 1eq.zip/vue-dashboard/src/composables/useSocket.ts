// src/composables/useSocket.ts
import { ref, onMounted, onUnmounted } from 'vue';
import { Socket } from 'socket.io-client';
import { socketService } from '@/services/socket';

export function useSocket(url: string): { socket: Socket | null } {
  const socket = ref<Socket | null>(null);

  onMounted(() => {
    socketService.connect(url);
    socket.value = socketService.getSocket();
    console.log('Socket connected');
  });

  onUnmounted(() => {
    socketService.disconnect();
    socket.value = null;
    console.log('Socket disconnected');
  });

  return { socket: socket.value };
}