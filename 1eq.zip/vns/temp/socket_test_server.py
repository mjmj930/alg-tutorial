import socket
import struct
import threading

# 服务端配置
HOST = '127.0.0.1'  # 本地监听地址
PORT = 8080         # 监听端口

# 处理单个客户端
def handle_client(client_socket, client_address):
    print(f"New connection from {client_address}")
    while True:
        try:
            # 读取消息头（固定8字节）
            header = client_socket.recv(8)
            if not header:
                print(f"Connection closed by {client_address}")
                break

            # 解析消息头
            msg_id, body_length = struct.unpack('!I I', header)  # 大端字节序解析
            print(f"Received Header: MsgID={hex(msg_id)}, BodyLength={body_length}")

            # 读取消息体
            body = client_socket.recv(body_length)
            print(f"Received Body: {body.decode('utf-8')}")

            # 根据消息ID处理消息并生成响应
            if msg_id == 0x01020304:  # 下行数据
                response_body = "Acknowledged Downlink Data"
                response_id = 0x02030405
            elif msg_id == 0x05060708:  # 上行数据
                response_body = "Acknowledged Uplink Data"
                response_id = 0x06070809
            else:  # 未知消息
                response_body = f"Unknown MsgID: {hex(msg_id)}"
                response_id = 0xFFFFFFFF

            # 构造响应消息
            response_body_bytes = response_body.encode('utf-8')
            response_header = struct.pack('!I I', response_id, len(response_body_bytes))
            response_message = response_header + response_body_bytes

            # 发送响应
            client_socket.send(response_message)
            print(f"Sent Response: MsgID={hex(response_id)}, Body={response_body}")
        except ConnectionResetError:
            print(f"Connection reset by {client_address}")
            break

    client_socket.close()
    print(f"Connection with {client_address} closed.")

# 启动服务端
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"Server is listening on {HOST}:{PORT}")

    while True:
        client_socket, client_address = server_socket.accept()
        threading.Thread(target=handle_client, args=(client_socket, client_address)).start()

if __name__ == "__main__":
    start_server()