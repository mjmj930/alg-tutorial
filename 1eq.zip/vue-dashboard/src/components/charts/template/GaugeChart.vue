<!-- src/components/charts/GaugeChart.vue -->
<template>
    <div ref="chartRef" class="gauge-chart"></div>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, onUnmounted, watch, ref, PropType } from 'vue';
  import * as echarts from 'echarts';
  import { hexToRgba } from '@/utils/helpers';
  
  export default defineComponent({
    name: 'GaugeChart',
    props: {
      value: {
        type: Number,
        required: true,
      },
      name: {
        type: String,
        default: '',
      },
      min: {
        type: Number,
        default: 0,
      },
      max: {
        type: Number,
        default: 100,
      },
    },
    setup(props) {
      const chartRef = ref<HTMLDivElement | null>(null);
      let chartInstance: echarts.ECharts | null = null;
  
      const initChart = () => {
        if (chartRef.value) {
          chartInstance = echarts.init(chartRef.value);
          const option = {
            series: [
              {
                type: 'gauge',
                detail: { formatter: `{value} ${props.name}`, fontSize: 16 },
                data: [{ value: props.value, name: props.name }],
                axisLine: {
                  lineStyle: {
                    color: [
                      [0.2, '#67e0e3'],
                      [0.8, '#37a2da'],
                      [1, '#fd666d'],
                    ],
                    width: 10,
                  },
                },
                min: props.min,
                max: props.max,
              },
            ],
          };
          chartInstance.setOption(option);
        }
      };
  
      const updateChart = () => {
        if (chartInstance) {
          chartInstance.setOption({
            series: [
              {
                data: [{ value: props.value, name: props.name }],
              },
            ],
          });
        }
      };
  
      onMounted(() => {
        initChart();
      });
  
      onUnmounted(() => {
        if (chartInstance) {
          chartInstance.dispose();
        }
      });
  
      watch(
        () => [props.value, props.name, props.min, props.max],
        () => {
          updateChart();
        },
        { deep: true }
      );
  
      return {
        chartRef,
      };
    },
  });
  </script>
  
  <style scoped>
  .gauge-chart {
    width: 100%;
    height: 100%;
  }
  </style>