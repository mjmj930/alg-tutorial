# Vue 3 + TypeScript + Vite

This template should help get you started developing with Vue 3 and TypeScript in Vite. The template uses Vue 3 `<script setup>` SFCs, check out the [script setup docs](https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup) to learn more.

Learn more about the recommended Project Setup and IDE Support in the [Vue Docs TypeScript Guide](https://vuejs.org/guide/typescript/overview.html#project-setup).

## descripiton

目录结构：

```
project/
├── public/
│   └── index.html
├── src/
│   ├── assets/
│   │   ├── images/
│   │   └── styles/
│   │       ├── main.css
│   │       ├── variables.scss
│   │       └── mixins.scss
│   ├── components/
│   │   ├── common/
│   │   │   ├── Header.vue
│   │   │   ├── Footer.vue
│   │   │   ├── Sidebar.vue
│   │   │   └── ...其他通用组件
│   │   ├── charts/
│   │   │   ├── GaugeChart.vue
│   │   │   ├── LineChart.vue
│   │   │   ├── BarChart.vue
│   │   │   └── ...其他图表组件
│   │   ├── layouts/
│   │   │   ├── DashboardLayout.vue
│   │   │   ├── AuthLayout.vue
│   │   │   └── ...其他布局组件
│   │   └── widgets/
│   │       ├── DataCard.vue
│   │       ├── StatusIndicator.vue
│   │       └── ...其他小组件
│   ├── composables/
│   │   ├── useSocket.ts
│   │   ├── useFetch.ts
│   │   └── ...其他组合式API
│   ├── router/
│   │   └── index.ts
│   ├── store/
│   │   ├── index.ts
│   │   ├── modules/
│   │   │   ├── userModule.ts
│   │   │   ├── bsModule.ts
│   │   │   └── ...其他Pinia模块
│   ├── services/
│   │   ├── api.ts
│   │   ├── socket.ts
│   │   └── ...其他服务
│   ├── types/
│   │   └── index.d.ts
│   ├── utils/
│   │   ├── helpers.ts
│   │   ├── constants.ts
│   │   └── ...其他工具函数
│   ├── views/
│   │   ├── UserDashboard/
│   │   │   ├── UserDashboard.vue
│   │   │   ├── components/
│   │   │   │   ├── UserSpecificChart.vue
│   │   │   │   └── ...用户级子组件
│   │   ├── BsDashboard/
│   │   │   ├── BsDashboard.vue
│   │   │   ├── components/
│   │   │   │   ├── BsSpecificChart.vue
│   │   │   │   └── ...基站级子组件
│   │   ├── Login/
│   │   │   └── Login.vue
│   │   └── ...其他视图
│   ├── App.vue
│   └── main.ts
├── .gitignore
├── package.json
├── tsconfig.json
├── vite.config.ts
└── ...

```
