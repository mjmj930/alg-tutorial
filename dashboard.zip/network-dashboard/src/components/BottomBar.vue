<template>
    <div class="bottom-bar">
      <div class="chart-container">
        <div class="chart-box">
          <div class="chart-title">
            <i>📈</i> 延迟 (ms)
          </div>
          <div ref="latencyChart" class="chart"></div>
        </div>
        <div class="chart-box">
          <div class="chart-title">
            <i>🔄</i> 丢包率 (%)
          </div>
          <div ref="packetLossChart" class="chart"></div>
        </div>
        <div class="chart-box">
          <div class="chart-title">
            <i>📡</i> 信号强度 (dBm)
          </div>
          <div ref="signalChart" class="chart"></div>
        </div>
      </div>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, ref, watch } from 'vue'
  import * as echarts from 'echarts'
  import { useNetworkStore } from '../stores/networkStore.ts'
  import { storeToRefs } from 'pinia'
  
  export default defineComponent({
    name: 'BottomBar',
    setup() {
      const networkStore = useNetworkStore()
      const { dataHistory } = storeToRefs(networkStore)
      
      const latencyChart = ref<HTMLElement | null>(null)
      const packetLossChart = ref<HTMLElement | null>(null)
      const signalChart = ref<HTMLElement | null>(null)
      
      let latencyInstance: echarts.ECharts | null = null
      let packetLossInstance: echarts.ECharts | null = null
      let signalInstance: echarts.ECharts | null = null
      
      const initCharts = () => {
        if (latencyChart.value && packetLossChart.value && signalChart.value) {
          latencyInstance = echarts.init(latencyChart.value)
          packetLossInstance = echarts.init(packetLossChart.value)
          signalInstance = echarts.init(signalChart.value)
          
          updateCharts()
        }
      }
      
      const updateCharts = () => {
        if (!latencyInstance || !packetLossInstance || !signalInstance) return
        
        const timestamps = dataHistory.value.map(item => item.timestamp)
        
        // 延迟图表配置
        const latencyOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0} ms'
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8',
              fontSize: 10
            }
          },
          yAxis: {
            type: 'value',
            name: 'ms',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          series: [{
            name: '延迟',
            type: 'line',
            smooth: true,
            data: generateRandomData(20, 5, 50, 3),
            symbol: 'none',
            lineStyle: {
              width: 2,
              color: '#00f2fe'
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(0, 242, 254, 0.3)' },
                { offset: 1, color: 'rgba(0, 242, 254, 0.05)' }
              ])
            }
          }]
        }
        
        // 丢包率图表配置
        const packetLossOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0}%'
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8',
              fontSize: 10
            }
          },
          yAxis: {
            type: 'value',
            name: '%',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          series: [{
            name: '丢包率',
            type: 'line',
            smooth: true,
            data: generateRandomData(20, 0, 5, 0.5),
            symbol: 'none',
            lineStyle: {
              width: 2,
              color: '#faad14'
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(250, 173, 20, 0.3)' },
                { offset: 1, color: 'rgba(250, 173, 20, 0.05)' }
              ])
            }
          }]
        }
        
        // 信号强度图表配置
        const signalOption = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            formatter: '{b}<br/>{a0}: {c0} dBm'
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: timestamps,
            axisLine: {
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8',
              fontSize: 10
            }
          },
          yAxis: {
            type: 'value',
            name: 'dBm',
            nameTextStyle: {
              color: '#8a9bb8'
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(138, 155, 184, 0.1)'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#8a9bb8'
              }
            },
            axisLabel: {
              color: '#8a9bb8'
            }
          },
          series: [{
            name: '信号强度',
            type: 'line',
            smooth: true,
            data: generateRandomData(20, -100, -60, 3),
            symbol: 'none',
            lineStyle: {
              width: 2,
              color: '#4facfe'
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(79, 172, 254, 0.3)' },
                { offset: 1, color: 'rgba(79, 172, 254, 0.05)' }
              ])
            }
          }]
        }
        
        latencyInstance.setOption(latencyOption)
        packetLossInstance.setOption(packetLossOption)
        signalInstance.setOption(signalOption)
      }
      
      const generateRandomData = (count: number, min: number, max: number, variation: number) => {
        let data = []
        let value = (min + max) / 2
        for (let i = 0; i < count; i++) {
          value = Math.min(max, Math.max(min, value + (Math.random() - 0.5) * variation))
          data.push(Number(value.toFixed(2)))
        }
        return data
      }
      
      const handleResize = () => {
        if (latencyInstance) latencyInstance.resize()
        if (packetLossInstance) packetLossInstance.resize()
        if (signalInstance) signalInstance.resize()
      }
      
      onMounted(() => {
        initCharts()
        window.addEventListener('resize', handleResize)
      })
      
      watch(dataHistory, () => {
        updateCharts()
      }, { deep: true })
      
      return {
        latencyChart,
        packetLossChart,
        signalChart
      }
    }
  })
  </script>
  
  <style scoped>
  .bottom-bar {
    background: rgba(16, 31, 63, 0.7);
    border-top: 1px solid rgba(79, 172, 254, 0.2);
    padding: 10px;
  }
  
  .chart-container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }
  
  .chart-box {
    background: rgba(16, 31, 63, 0.5);
    border-radius: 6px;
    padding: 8px;
  }
  
  .chart-title {
    font-size: 0.9rem;
    color: #8a9bb8;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
  }
  
  .chart-title i {
    margin-right: 5px;
  }
  
  .chart {
    width: 100%;
    height: 120px;
  }
  
  @media (max-width: 768px) {
    .chart-container {
      grid-template-columns: 1fr;
    }
    
    .chart {
      height: 100px;
    }
  }
  </style>