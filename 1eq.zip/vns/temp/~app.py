# ~app.py

from flask import Flask, jsonify, request
import logging
import os
from client_socket import UESocketClient
from storage import JSONStorage
from message_constants import (
    SUBSCRIBE_REQ_MSGID,  # example: 0x09201012
    IND_MSGID  # example: 0x01201F01
)

app = Flask(__name__)
storage = JSONStorage("ue_data.json")

# 设置 logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)


@app.route("/handshake", methods=["POST"])
def handshake():
    """
    POST /handshake
    触发握手流程
    参数可选: aucPara, ulCnntInfo (JSON)
    """
    data = request.json if request.is_json else {}
    aucPara = data.get("aucPara", 0)
    ulCnntInfo = data.get("ulCnntInfo", 0)

    client = UESocketClient()
    try:
        res = client.shakehand(aucPara, ulCnntInfo)
    except Exception as e:
        app.logger.error(f"Handshake exception: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        client.close()

    return jsonify(res)


@app.route("/heartbeat", methods=["GET"])
def heartbeat():
    """
    GET /heartbeat
    初始化一次心跳
    """
    client = UESocketClient()
    try:
        client.connect()
        res = client.heartbeat()
    except Exception as e:
        app.logger.error(f"Heartbeat exception: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        client.close()

    return jsonify(res)


@app.route("/subscribe", methods=["POST"])
def subscribe():
    """
    POST /subscribe
    body = {
      "msgId": 0x09201012,    # 要订阅的消息ID
      "isRegister": 1         # 1=订阅, 0=取消订阅
    }
    """
    data = request.json if request.is_json else {}
    msgId = data.get("msgId", SUBSCRIBE_REQ_MSGID)
    isRegister = data.get("isRegister", 1)

    client = UESocketClient()
    try:
        client.connect()
        res = client.subscribe(msgId, isRegister)
    except Exception as e:
        app.logger.error(f"Subscribe exception: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        client.close()

    return jsonify(res)


@app.route("/receive_ind", methods=["GET"])
def receive_ind():
    """
    GET /receive_ind
    尝试接收 UE 上报的 IND 消息，并存储到 JSON 文件
    """
    client = UESocketClient()
    try:
        client.connect()
        # 主动调用 receive_ind() 等待 UE 上报
        ind_data = client.receive_ind()
        # 将数据存储
        storage.save_record(ind_data)
    except Exception as e:
        app.logger.error(f"Receive IND exception: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        client.close()

    return jsonify(ind_data)


@app.route("/query_data", methods=["GET"])
def query_data():
    """
    GET /query_data
    查询存储的 UE 数据(示例)
    """
    data = storage.load_all()
    return jsonify(data)


def main():
    app.run(host="0.0.0.0", port=5000, debug=True)


if __name__ == "__main__":
    main()
