<template>
  <router-view />
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'App'
})
</script>

<style>
body {
  margin: 0;
  padding: 0;
  background-color: #0f1621;
  color: #e0e0e0;
  font-family: 'Arial', sans-serif;
  overflow-x: hidden;
}
</style>