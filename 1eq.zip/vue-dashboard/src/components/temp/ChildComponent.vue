<template>
    <div class="mt-4 border-t pt-4">
      <h2 class="text-lg font-semibold">子组件</h2>
      <p><strong>DL Throughput:</strong> {{ ueData.dl_throughput }} Mbps</p>
      <p><strong>UL Throughput:</strong> {{ ueData.ul_throughput }} Mbps</p>
      <p><strong>DL RLC Throughput:</strong> {{ bsData.dl_rlc_throughput }} Mbps</p>
      <p><strong>General User Number:</strong> {{ bsData.general_user_number }}</p>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent, PropType } from 'vue';
  import { UeDataItem, BsDataItem } from '@/services/DataService';
  
  export default defineComponent({
    name: 'ChildComponent',
    props: {
      ueData: {
        type: Object as PropType<UeDataItem>,
        required: true
      },
      bsData: {
        type: Object as PropType<BsDataItem>,
        required: true
      }
    }
  });
  </script>
  
  <style scoped>
  /* 添加样式 */
  </style>