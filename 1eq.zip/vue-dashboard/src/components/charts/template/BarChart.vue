<!-- src/components/charts/BarChart.vue -->
<template>
    <div ref="chartRef" class="bar-chart"></div>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, onUnmounted, watch, ref, PropType } from 'vue';
  import * as echarts from 'echarts';
  import { hexToRgba } from '@/utils/helpers';
  
  export default defineComponent({
    name: 'BarChart',
    props: {
      title: {
        type: String,
        default: '',
      },
      xData: {
        type: Array as PropType<string[]>,
        required: true,
      },
      yData: {
        type: Array as PropType<number[]>,
        required: true,
      },
      color: {
        type: String,
        default: '#37a2da',
      },
    },
    setup(props) {
      const chartRef = ref<HTMLDivElement | null>(null);
      let chartInstance: echarts.ECharts | null = null;
  
      const initChart = () => {
        if (chartRef.value) {
          chartInstance = echarts.init(chartRef.value);
          const option = {
            title: {
              text: props.title,
              textStyle: {
                color: '#fff',
              },
              left: 'center',
            },
            tooltip: {
              trigger: 'axis',
            },
            xAxis: {
              type: 'category',
              data: props.xData,
              axisLabel: { color: '#fff' },
            },
            yAxis: {
              type: 'value',
              axisLabel: { color: '#fff' },
            },
            series: [
              {
                data: props.yData,
                type: 'bar',
                itemStyle: { color: props.color },
              },
            ],
          };
          chartInstance.setOption(option);
        }
      };
  
      const updateChart = () => {
        if (chartInstance) {
          chartInstance.setOption({
            xAxis: {
              data: props.xData,
            },
            series: [
              {
                data: props.yData,
              },
            ],
          });
        }
      };
  
      onMounted(() => {
        initChart();
      });
  
      onUnmounted(() => {
        if (chartInstance) {
          chartInstance.dispose();
        }
      });
  
      watch(
        () => [props.xData, props.yData, props.color],
        () => {
          updateChart();
        },
        { deep: true }
      );
  
      return {
        chartRef,
      };
    },
  });
  </script>
  
  <style scoped>
  .bar-chart {
    width: 100%;
    height: 100%;
  }
  </style>