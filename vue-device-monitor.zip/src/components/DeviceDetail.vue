<template>
  <div class="device-detail-container p-6 max-w-4xl mx-auto">
    <div class="flex justify-between items-center mb-6">
      <h2 class="text-2xl font-bold">设备详情: {{ device.name }}</h2>
      <button 
        class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors duration-200"
        @click="goBack"
      >
        返回
      </button>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      <div class="bg-white p-6 rounded-xl shadow-lg">
        <h3 class="text-lg font-semibold mb-4">基本信息</h3>
        <div class="space-y-3">
          <div class="flex justify-between">
            <span class="text-gray-500">设备ID</span>
            <span class="font-medium">{{ device.id }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">设备名称</span>
            <span class="font-medium">{{ device.name }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">IP地址</span>
            <span class="font-medium">{{ device.ip }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">设备状态</span>
            <span 
              class="px-3 py-1 rounded-full text-xs font-medium"
              :class="{'bg-green-100 text-green-800': device.status === 'online', 'bg-red-100 text-red-800': device.status === 'offline'}"
            >
              {{ device.status }}
            </span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-500">在线时长</span>
            <span class="font-medium">{{ device.onlineTime }}小时</span>
          </div>
        </div>
      </div>
      
      <div class="bg-white p-6 rounded-xl shadow-lg">
        <h3 class="text-lg font-semibold mb-4">性能指标</h3>
        <div class="space-y-4">
          <div>
            <div class="flex justify-between mb-1">
              <span class="text-sm">CPU使用率</span>
              <span class="text-sm font-medium">{{ device.cpuUsage }}%</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div 
                class="bg-blue-600 h-2 rounded-full"
                :style="{ width: `${device.cpuUsage}%` }"
              ></div>
            </div>
          </div>
          
          <div>
            <div class="flex justify-between mb-1">
              <span class="text-sm">内存使用率</span>
              <span class="text-sm font-medium">{{ device.memoryUsage }}%</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div 
                class="bg-purple-600 h-2 rounded-full"
                :style="{ width: `${device.memoryUsage}%` }"
              ></div>
            </div>
          </div>
          
          <div>
            <div class="flex justify-between mb-1">
              <span class="text-sm">磁盘使用率</span>
              <span class="text-sm font-medium">{{ device.diskUsage }}%</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div 
                class="bg-orange-600 h-2 rounded-full"
                :style="{ width: `${device.diskUsage}%` }"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="bg-white p-6 rounded-xl shadow-lg mb-8">
      <h3 class="text-lg font-semibold mb-4">网络流量分析</h3>
      <div class="h-80">
        <!-- 这里会渲染图表 -->
        <canvas id="trafficChart"></canvas>
      </div>
    </div>
    
    <div class="bg-white p-6 rounded-xl shadow-lg">
      <h3 class="text-lg font-semibold mb-4">最近事件</h3>
      <div class="space-y-3">
        <div class="p-3 border-l-4 border-blue-500 bg-blue-50 rounded">
          <div class="flex justify-between">
            <span class="font-medium">系统重启</span>
            <span class="text-sm text-gray-500">10分钟前</span>
          </div>
          <p class="text-sm text-gray-600 mt-1">设备正常重启完成，所有服务已恢复运行</p>
        </div>
        
        <div class="p-3 border-l-4 border-yellow-500 bg-yellow-50 rounded">
          <div class="flex justify-between">
            <span class="font-medium">CPU警告</span>
            <span class="text-sm text-gray-500">1小时前</span>
          </div>
          <p class="text-sm text-gray-600 mt-1">CPU使用率超过80%，持续时间15分钟</p>
        </div>
        
        <div class="p-3 border-l-4 border-green-500 bg-green-50 rounded">
          <div class="flex justify-between">
            <span class="font-medium">软件更新</span>
            <span class="text-sm text-gray-500">3小时前</span>
          </div>
          <p class="text-sm text-gray-600 mt-1">系统软件已更新到最新版本</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useDevicesStore } from '@/stores/devices'
import Chart from 'chart.js/auto'
import { onDeviceSelect } from '@/utils/eventmitt'

const route = useRoute()
const router = useRouter()
const devicesStore = useDevicesStore()
const deviceId = route.params.id as string
const device = ref(devicesStore.getDeviceById(deviceId) || {})
const chart = ref<Chart | null>(null)

// 初始化图表
const initChart = () => {
  if (!device.value || !device.value.trafficHistory) return
  
  const ctx = document.getElementById('trafficChart') as HTMLCanvasElement
  
  // 如果已有图表实例，销毁它
  if (chart.value) {
    chart.value.destroy()
  }
  
  // 创建新图表
  chart.value = new Chart(ctx, {
    type: 'line',
    data: {
      labels: device.value.trafficHistory.map(h => h.time),
      datasets: [{
        label: '入站流量 (MB/s)',
        data: device.value.trafficHistory.map(h => h.incoming),
        borderColor: '#3B82F6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.3,
        fill: true
      }, {
        label: '出站流量 (MB/s)',
        data: device.value.trafficHistory.map(h => h.outgoing),
        borderColor: '#F97316',
        backgroundColor: 'rgba(249, 115, 22, 0.1)',
        tension: 0.3,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
        },
        tooltip: {
          mode: 'index',
          intersect: false,
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      },
      animation: {
        duration: 1000,
        easing: 'easeOutQuart'
      }
    }
  })
}

// 返回上一页
const goBack = () => {
  router.back()
}

// 监听设备选择事件
const unsubscribe = onDeviceSelect((selectedId: string) => {
  if (selectedId === deviceId) {
    device.value = devicesStore.getDeviceById(deviceId) || {}
    initChart()
  }
})

// 生命周期钩子
onMounted(() => {
  // 初始加载设备数据
  devicesStore.fetchDeviceDetail(deviceId).then(() => {
    device.value = devicesStore.getDeviceById(deviceId) || {}
    initChart()
  })
  
  // 添加窗口大小变化监听，更新图表
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  // 清理图表
  if (chart.value) {
    chart.value.destroy()
  }
  
  // 移除事件监听
  window.removeEventListener('resize', handleResize)
  
  // 取消事件订阅
  unsubscribe()
})

// 窗口大小变化处理
const handleResize = () => {
  initChart()
}

// 监听路由变化
watch(() => route.params.id, (newId) => {
  if (newId !== deviceId) {
    deviceId = newId as string
    devicesStore.fetchDeviceDetail(deviceId).then(() => {
      device.value = devicesStore.getDeviceById(deviceId) || {}
      initChart()
    })
  }
})
</script>  