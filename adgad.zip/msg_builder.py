from msg_struct import APP_MSG_HEADER, MESSAGE_BODY_STRUCTS, Metric1


def build_message(msgid: int, data: dict) -> bytes:
    """构建协议消息（大端序）"""
    # 1. 获取消息体结构体
    body_struct = MESSAGE_BODY_STRUCTS[msgid]

    # 2. 构建消息体
    body_data = body_struct.build(data)

    # 3. 计算总长度（头部2字节 + 消息体长度）
    total_len = 2 + len(body_data)
    if total_len > 0xFF:
        raise ValueError(f"消息过长（{total_len}字节），协议限制255字节")

    # 4. 构建消息头
    header = APP_MSG_HEADER.build({
        "magicnumber": 0xAB,
        "MsgLen": total_len
    })

    # 5. 返回完整消息
    return header + body_data


def build_msg_metric1(value1: float, value2: int) -> bytes:
    """构建自定义消息 metric1"""
    msg_len = Metric1.sizeof() - 4  # 计算消息长度（减去 MsgID 的 4 字节）
    msg = Metric1.build(
        {
            "APP_MSG_HEADER": {"magicnumber": 0xAB, "MsgLen": msg_len},
            "MsgId": 0x4001,  # 假设 metric1 的 MsgID 是 0x4001
            "value1": value1,
            "value2": value2
        }
    )
    return msg