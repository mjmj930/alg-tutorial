// src/stores/networkStore.ts
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { useIntervalFn } from '@vueuse/core'

interface NetworkData {
  timestamp: string
  uplink: number
  downlink: number
  rsrp: number
}

export const useNetworkStore = defineStore('network', () => {
  const dataHistory = ref<NetworkData[]>([])
  const maxDataPoints = 20

  // 生成初始数据
  const generateInitialData = () => {
    const now = new Date()
    const initialData: NetworkData[] = []
    
    for (let i = maxDataPoints - 1; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 1000)
      initialData.push({
        timestamp: time.toLocaleTimeString(),
        uplink: Math.random() * 30 + 10,
        downlink: Math.random() * 60 + 30,
        rsrp: -Math.floor(Math.random() * 30 + 70)
      })
    }
    
    return initialData
  }

  // 初始化数据
  dataHistory.value = generateInitialData()

  // 更新数据
  const updateData = () => {
    const now = new Date()
    const newData: NetworkData = {
      timestamp: now.toLocaleTimeString(),
      uplink: Math.random() * 30 + 10,
      downlink: Math.random() * 60 + 30,
      rsrp: -Math.floor(Math.random() * 30 + 70)
    }
    
    if (dataHistory.value.length >= maxDataPoints) {
      dataHistory.value.shift()
    }
    dataHistory.value.push(newData)
  }

  // 当前最新数据
  const currentData = computed(() => {
    return dataHistory.value[dataHistory.value.length - 1] || {
      uplink: 0,
      downlink: 0,
      rsrp: 0
    }
  })

  // 定时更新数据
  useIntervalFn(updateData, 2000)

  return {
    dataHistory,
    currentData
  }
})