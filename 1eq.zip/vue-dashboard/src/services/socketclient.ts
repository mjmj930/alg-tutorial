// src/socketClient.ts

import { io, Socket } from 'socket.io-client';
import { BsData, TueData, UpdateData } from './types';

class SocketClient {
    private socket: Socket;
    private readonly SERVER_URL: string = 'http://localhost:5000'; // 修改为您的 Flask 服务器地址和端口

    constructor() {
        this.socket = io(this.SERVER_URL, {
            reconnectionAttempts: 5, // 重连次数
            timeout: 10000,          // 连接超时设置（毫秒）
        });

        this.initialize();
    }

    private initialize(): void {
        this.socket.on('connect', () => {
            console.log('Connected to server');
        });

        this.socket.on('disconnect', (reason: string) => {
            console.log(`Disconnected: ${reason}`);
        });

        this.socket.on('connect_error', (error: Error) => {
            console.error(`Connection Error: ${error.message}`);
        });

        this.socket.on('update_data', (data: UpdateData) => {
            this.handleUpdateData(data);
        });
    }

    private handleUpdateData(data: UpdateData): void {
        console.log('Received data:', data);
        // 您可以在这里进行数据处理，例如存储、转发等
        // 例如：
        this.processBsData(data.bs_data);
        this.processTueData(data.tue_data);
    }

    private processBsData(bsData: BsData): void {
        // 在这里处理 BS 数据
        console.log('BS Data:', bsData);
        // 访问 DL RLC 吞吐量
        console.log(`DL RLC Throughput: ${bsData.dlRlcThroughput}`);
    }

    private processTueData(tueData: TueData): void {
        // 在这里处理 TUE 数据
        console.log('TUE Data:', tueData);
        // 示例：访问 UL MCS
        console.log(`UL MCS: ${tueData.ulMcs}`);
    }

    public disconnect(): void {
        this.socket.disconnect();
    }
}

export default SocketClient;
