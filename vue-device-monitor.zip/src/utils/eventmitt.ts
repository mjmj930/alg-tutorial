import mitt from 'mitt'

// 定义事件类型
type Events = {
  'device:select': string
}

// 创建事件总线实例
const emitter = mitt<Events>()

// 发送设备选择事件
export const emitDeviceSelect = (deviceId: string) => {
  emitter.emit('device:select', deviceId)
}

// 监听设备选择事件
export const onDeviceSelect = (handler: (deviceId: string) => void) => {
  emitter.on('device:select', handler)
  
  // 返回取消订阅函数
  return () => {
    emitter.off('device:select', handler)
  }
}  