<template>
  <div class="chart-container">
    <h2 class="chart-title">上行/下行RSRp趋势</h2>
    <div ref="chartRef" class="chart"></div>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted, onBeforeUnmount, ref, toRefs } from 'vue';
import * as echarts from "echarts";
import eventBus from '../utils/eventBus'

interface RSRpData {
  time: string[];
  uplink: number[];
  downlink: number[];
}

export default defineComponent({
  name: 'RSRpChart',
  props: {
    showUplink: {
      type: Boolean,
      default: true
    }
  },
  setup(props) {
    const { showUplink } = toRefs(props)
    const chartRef = ref<HTMLDivElement>();
    let chartInstance: echarts.ECharts | null = null;
    
    const chartData = ref<RSRpData>({
      time: [],
      uplink: [],
      downlink: []
    });

    const initChart = () => {
      if (!chartRef.value) return;
      
      chartInstance = echarts.init(chartRef.value);
      updateChart();
      window.addEventListener('resize', handleResize);
    };
    
    const updateChart = () => {
      if (!chartInstance) return;
      
      const option: echarts.EChartsOption = {
        backgroundColor: 'rgba(20, 28, 50, 0.7)',
        title: {
          text: 'RSRp (dBm)',
          left: 'center',
          textStyle: {
            color: '#e2e8f0',
            fontSize: 16
          }
        },
        tooltip: {
          trigger: 'axis',
          backgroundColor: 'rgba(15, 25, 50, 0.9)',
          borderColor: '#4c6fff',
          textStyle: { color: '#e2e8f0' },
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          }
        },
        legend: {
          data: showUplink.value ? ['上行RSRp'] : ['下行RSRp'],
          top: 35,
          textStyle: { color: '#94a3b8' }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          top: '20%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: chartData.value.time,
          axisLine: { lineStyle: { color: '#4b5563' } },
          axisLabel: { color: '#94a3b8' }
        },
        yAxis: {
          type: 'value',
          min: -120,
          max: -70,
          axisLine: { show: true, lineStyle: { color: '#4b5563' } },
          axisLabel: { color: '#94a3b8' },
          splitLine: { lineStyle: { color: 'rgba(75, 85, 99, 0.5)', type: 'dashed' } }
        },
        series: showUplink.value ? [
          {
            name: '上行RSRp',
            type: 'line',
            smooth: true,
            stack: 'total',
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(45, 212, 191, 0.6)' },
                { offset: 1, color: 'rgba(45, 212, 191, 0.1)' }
              ])
            },
            lineStyle: {
              width: 3,
              color: '#0d9488'
            },
            showSymbol: false,
            data: chartData.value.uplink
          }
        ] : [
          {
            name: '下行RSRp',
            type: 'line',
            smooth: true,
            stack: 'total',
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(96, 165, 250, 0.6)' },
                { offset: 1, color: 'rgba(96, 165, 250, 0.1)' }
              ])
            },
            lineStyle: {
              width: 3,
              color: '#3b82f6'
            },
            showSymbol: false,
            data: chartData.value.downlink
          }
        ],
        animation: true,
        animationDuration: 500
      };
      
      chartInstance.setOption(option);
    };
    
    const handleResize = () => {
      chartInstance?.resize();
    };
    
    const updateData = () => {
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
      
      chartData.value.time.push(timeStr);
      // 模拟RSRp数据（正常范围：-70dBm 到 -120dBm）
      chartData.value.uplink.push(Math.round(-85 + Math.random() * 15));
      chartData.value.downlink.push(Math.round(-95 + Math.random() * 20));
      
      if (chartData.value.time.length > 15) {
        chartData.value.time.shift();
        chartData.value.uplink.shift();
        chartData.value.downlink.shift();
      }
      
      updateChart();
    };
    
    onMounted(() => {
      initChart();
      
      // 初始化数据
      const now = new Date();
      for (let i = 14; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 2000);
        const timeStr = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}:${time.getSeconds().toString().padStart(2, '0')}`;
        chartData.value.time.push(timeStr);
        chartData.value.uplink.push(Math.round(-85 + Math.random() * 15));
        chartData.value.downlink.push(Math.round(-95 + Math.random() * 20));
      }
      
      updateChart();
      
      const timer = setInterval(updateData, 2000);

      const handleToggleDataDisplay = (isUplink: boolean) => {
        showUplink.value = isUplink
        updateChart()
      }

      eventBus.on('toggleDataDisplay', handleToggleDataDisplay)

      onBeforeUnmount(() => {
        clearInterval(timer);
        window.removeEventListener('resize', handleResize);
        chartInstance?.dispose();
        eventBus.off('toggleDataDisplay', handleToggleDataDisplay)
      });
    });
    
    return {
      chartRef
    };
  }
});
</script>

<style scoped>
.chart-container {
  background: linear-gradient(145deg, #1e293b, #0f172a);
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(74, 85, 104, 0.5);
}

.chart-title {
  color: #e2e8f0;
  margin-bottom: 20px;
  font-size: 1.4rem;
  text-align: center;
  font-weight: 500;
}

.chart {
  width: 100%;
  height: 400px;
}
</style>