<!-- src/views/BsDashboard/components/BsSideBar.vue -->
<template>
    <div>
      <div class="header-section">
        <h2>基站</h2>
      </div>
      <div class="data-section">
        <DataCard
          v-for="item in dataItems"
          :key="item.id"
          :title="item.title"
          :value="item.value"
        />
      </div>
      <GaugeChart :value="rsrp" name="RSRP" />
    </div>
  </template>

  <script lang="ts">
  import { defineComponent, computed } from 'vue';
  import { useBsStore } from '@/store/modules/bsModule.ts';
  import DataCard from '@/components/widgets/DataCard.vue';
  import GaugeChart from '@/components/charts/template/GaugeChart.vue';

  export default defineComponent({
    name: 'BsSidebar',
    components: {
      DataCard,
      GaugeChart,
    },
    setup() {
      const bsStore = useBsStore();

      const dataItems = computed(() => bsStore.dataItems);
      const rsrp = computed(() => bsStore.rsrp);

      return {
        dataItems,
        rsrp,
      };
    },
  });
  </script>

  <style scoped>
  .header-section {
    text-align: center;
    margin-bottom: 20px;
    font-size: 18px;
  }

  .data-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 20px;
  }
  </style>
