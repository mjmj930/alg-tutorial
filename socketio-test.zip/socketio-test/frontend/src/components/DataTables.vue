<template>
  <div class="data-table-container">
    <h2>实时数据</h2>
    <table>
      <thead>
        <tr>
          <th>属性</th>
          <th>值</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>UplinkThroughput</td>
          <td>{{ data?.UplinkThroughput }}</td>
        </tr>
        <tr>
          <td>UplinkSINR</td>
          <td>{{ data?.UplinkSINR }}</td>
        </tr>
        <tr>
          <td>UplinkMCS</td>
          <td>{{ data?.UplinkMCS }}</td>
        </tr>
        <tr>
          <td>UplinkTxPower</td>
          <td>{{ data?.UplinkTxPower }}</td>
        </tr>
        <tr>
          <td>UplinkRetransmissionRate</td>
          <td>{{ data?.UplinkRetransmissionRate }}</td>
        </tr>
        <tr>
          <td>DownlinkThroughput</td>
          <td>{{ data?.DownlinkThroughput }}</td>
        </tr>
        <tr>
          <td>DownlinkSINR</td>
          <td>{{ data?.DownlinkSINR }}</td>
        </tr>
        <tr>
          <td>DownlinkMCS</td>
          <td>{{ data?.DownlinkMCS }}</td>
        </tr>
        <tr>
          <td>RSRP</td>
          <td>{{ data?.RSRP }}</td>
        </tr>
        
        <tr>
          <td>T1UplinkThroughput</td>
          <td>{{ data?.T1UplinkThroughput }}</td>
        </tr>
        <tr>
          <td>T1UplinkSINR</td>
          <td>{{ data?.T1UplinkSINR }}</td>
        </tr>
        <tr>
          <td>T1UplinkMCS</td>
          <td>{{ data?.T1UplinkMCS }}</td>
        </tr>
        <tr>
          <td>T1UplinkTxPower</td>
          <td>{{ data?.T1UplinkTxPower }}</td>
        </tr>
        <tr>
          <td>T1UplinkRetransmissionRate</td>
          <td>{{ data?.T1UplinkRetransmissionRate }}</td>
        </tr>
        <tr>
          <td>T1DownlinkThroughput</td>
          <td>{{ data?.T1DownlinkThroughput }}</td>
        </tr>
        <tr>
          <td>T1DownlinkSINR</td>
          <td>{{ data?.T1DownlinkSINR }}</td>
        </tr>
        <tr>
          <td>T1DownlinkMCS</td>
          <td>{{ data?.T1DownlinkMCS }}</td>
        </tr>
        <tr>
          <td>T1RSRP</td>
          <td>{{ data?.T1RSRP }}</td>
        </tr>
      </tbody>
    </table>
    
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { useDataStore } from '../stores/dataStore'

const store = useDataStore()
// 使用 computed 使得 data 发生变化时组件自动更新
const data = computed(() => store.data)
</script>

<style scoped>
.data-table-container {
  width: 100%;
  margin: 0 auto;
  max-width: 800px;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
  border-radius: 5px;
  overflow: hidden;
}

th, td {
  padding: 12px 15px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 1px;
}

tbody tr:nth-child(even) {
  background-color: #f9f9f9;
}

tbody tr:hover {
  background-color: #eaeaea;
}

tbody td:last-child {
  font-weight: bold;
}
</style>