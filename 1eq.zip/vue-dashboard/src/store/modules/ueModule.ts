// src/store/modules/ueModule.ts
import { defineStore } from 'pinia';
import { MAX_DATA_POINTS } from '@/utils/constants';
import { io } from 'socket.io-client';

interface UeDataItem {
  id: string;
  title: string;
  value: string | number;
  unit: string;
}

export const useUeStore = defineStore('ue', {
  state: () => ({
    dataItems: [
      { id: 'ul-mcs', title: '上行MCS', value: 0 },
      // { id: 'dl-mcs', title: '下行MCS', value: 0 },
      { id: 'dl-mimo-rank', title: 'DL MIMO RANK', value: 0 },
      { id: 'ul-bler', title: 'UL BLER', value: 0 , unit: '%'},
      // { id: 'dl-bler', title: 'DL BLER', value: 0 , unit: '%'},
      // { id: 'ul-throughput', title: 'UL Throughput', value: 0 , unit: 'Mbps'},
      // { id: 'dl-throughput', title: 'DL Throughput', value: 0 , unit: 'Mbps'},
      // { id: 'dl-rsrp', title: 'Downlink RSRP', value: 0 , unit: 'dBm'},
      { id: 'ul-ssb-rank', title: 'UpLink SSB RANK', value: 0},
      { id: 'csi-sinr', title: 'CSI SINR', value: 0, unit: 'dB'},
      { id: 'dmrs-sinr', title: 'DMRS SINR', value: 0, unit: 'dB' },
    ] as UeDataItem[],
    peakRate: 0,
    rlcTime: [] as string[],
    downlinkRLC: [] as number[],
    uplinkRLC: [] as number[],
    cpuTime: [] as string[],
    cpuUsage: [] as number[],
    memoryTime: [] as string[],
    memoryUsage: [] as number[],
    socket: null as any, // 假设已经初始化 Socket.IO 客户端
  }),
  actions: {
    // 更新数据项
    updateDataItems(data: any) {
      this.dataItems.forEach((item) => {
        if (data.hasOwnProperty(item.id)) {
          item.value = data[item.id];
        }
      });
      this.peakRate = parseFloat(data.speed) || 0;
      this.cpuUsage = parseFloat(data.cpuUsage) || 0;
      this.memoryUsage = parseFloat(data.memoryUsage) || 0;
    },
    // 添加时间点和 RLC 数据
    addRLCData(time: string, downlink: number, uplink: number) {
      this.rlcTime.push(time);
      this.downlinkRLC.push(downlink);
      this.uplinkRLC.push(uplink);
      if (this.rlcTime.length > MAX_DATA_POINTS) {
        this.rlcTime.shift();
        this.downlinkRLC.shift();
        this.uplinkRLC.shift();
      }
    },
    // 添加 CPU 使用率数据
    addCPUUsage(time: string, usage: number) {
      this.cpuTime.push(time);
      this.cpuUsage.push(usage);
      if (this.cpuTime.length > MAX_DATA_POINTS) {
        this.cpuTime.shift();
        this.cpuUsage.shift();
      }
    },
    // 添加内存使用量数据
    addMemoryUsage(time: string, usage: number) {
      this.memoryTime.push(time);
      this.memoryUsage.push(usage);
      if (this.memoryTime.length > MAX_DATA_POINTS) {
        this.memoryTime.shift();
        this.memoryUsage.shift();
      }
    },
    // Socket.IO 事件处理（示例）
    initializeSocket() {
      // 假设已安装并导入 Socket.IO 客户端
      this.socket = io('http://your-socket-server');
      this.socket.on('ueData', (data: any) => {
        this.updateDataItems(data);
        const now = new Date();
        const time = `${now.getHours().toString().padStart(2, '0')}:${now
          .getMinutes()
          .toString()
          .padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
        this.addRLCData(time, parseFloat(data.downlinkRLC) || 0, parseFloat(data.uplinkRLC) || 0);
        this.addCPUUsage(time, parseFloat(data.cpuUsage) || 0);
        this.addMemoryUsage(time, parseFloat(data.memoryUsage) || 0);
      });
    },
  },
});