<template>
  <div id="app">
    <SpeedDashboard />
  </div>
</template>

<script lang="ts" setup>
import SpeedDashboard from './components/SpeedDashboard.vue'
</script>

<style>
#app {
  font-family: 'Arial', sans-serif;
  background-color: #0a0a1a;
  color: white;
  min-height: 100vh;
  margin: 0;
  padding: 0;
  overflow: hidden;
}
</style>    