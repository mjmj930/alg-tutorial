import { createApp } from 'vue'
import App from './App.vue'
import { createPinia } from 'pinia'

// 引入 ECharts
import * as echarts from 'echarts'

// 创建应用实例
const app = createApp(App)

// 使用 Pinia
app.use(createPinia())

// 全局注册 ECharts
app.config.globalProperties.$echarts = echarts

// 挂载应用
app.mount('#app')    