<!-- src/views/UserDashboard/UeDashboard.vue -->
<template>
  <DashboardLayout>
    <!-- 左侧栏内容 -->
    <template #sidebar>
      <UeSidebar />
    </template>

    <!-- 底部栏内容 -->
    <template #bottom-bar>
      <UserDashboardCharts />
    </template>

    <!-- 右上部分地图已经在 DashboardLayout 中定义 -->
  </DashboardLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import DashboardLayout from '@/components/layouts/Layout.vue';
import UeSidebar from '@/components/common/UeSideBar.vue';
import UserDashboardCharts from '@/components/common/UeBottomBar.vue';

export default defineComponent({
  name: 'UserDashboard',
  components: {
    DashboardLayout,
    UeSidebar,
    UserDashboardCharts,
  },
});
</script>

<style scoped>
/* 根据需要添加特定样式 */
</style>
