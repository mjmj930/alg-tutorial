// src/components/types.ts

export interface BsData {
    dlRlcThroughput: string;           // 下行 RLC 吞吐量 (Kbps)
    ulRlcThroughput: string;           // 上行 RLC 吞吐量 (Kbps)
    generalUserNumber: number;         // 一般用户数量
    dlUsedRbNum: number;               // 下行使用的 RB 数量
    ulUsedRbNum: number;               // 上行使用的 RB 数量
    downlinkStreamNum: number;         // 下行流数量
    uplinkStreamNum: number;           // 上行流数量
    dlPdschAckNum: PdschAckNum;        // DL PDSCH Code0/1/2/3 ACK 数量
    dlPuschNackNum: PuschNackNum;      // DL PUSCH Code0/1/2/3 NACK 数量
    ulPdschDtxNum: PdschDtxNum;        // UL PDSCH Code0/1/2/3 DTX 数量
  }
  
  export interface PdschAckNum {
    code0: number;
    code1: number;
    code2: number;
    code3: number;
  }
  
  export interface PuschNackNum {
    code0: number;
    code1: number;
    code2: number;
    code3: number;
  }
  
  export interface PdschDtxNum {
    code0: number;
    code1: number;
    code2: number;
    code3: number;
  }