<template>
  <el-card class="data-card" @click="handleToggle" :style="{ padding: contentPadding }">
    <!-- 标题 -->
    <h3
      class="data-card-title"
      :style="{
        color: titleColor,
        fontSize: titleFontSize,
        padding: titlePadding,
        margin: titleMargin,
        textAlign: titleAlignment,
      }"
    >
      {{ title }}
    </h3>
    <!-- 数值 -->
    <div
      class="data-card-value"
      :style="{
        color: valueColor,
        fontSize: valueFontSize,
      }"
    >
      {{ value }}
    </div>
  </el-card>
</template>


<script>
export default {
  name: "DataCard", // 组件名
  props: {
    id: {
      type: String, // 唯一 ID
      required: true,
    },
    title: {
      type: String, // 卡片标题
      required: true,
    },
    value: {
      type: [String, Number], // 卡片展示的值
      required: true,
    },
    interactive: {
      type: Boolean, // 是否允许交互
      default: false,
    },
    titleColor: {
      type: String, // 动态设置标题颜色
      default: "#fff", // 默认白色
    },
    valueColor: {
      type: String, // 动态设置数值颜色
      default: "#f0f0f0", // 默认浅灰色
    },
    titleFontSize: {
      type: String, // 动态设置标题字体大小
      default: "18px", // 默认字体大小为 14px
    },
    valueFontSize: {
      type: String, // 动态设置数值字体大小
      default: "20px", // 默认字体大小为 20px
    },
  titlePadding: {
      type: String, // 标题的内边距
      default: "0", // 默认无内边距
    },
    valuePadding: {
      type: String, // 数值的内边距
      default: "0", // 默认无内边距
    },
    titleMargin: {
      type: String, // 标题的外边距
      default: "0", // 默认无外边距
    },
    valueMargin: {
      type: String, // 数值的外边距
      default: "11px 0 0 0", // 默认数值与标题之间有 5px 的间距
    },
    titleAlignment: {
      type: String, // 标题的对齐方式
      default: "left", // 默认左对齐，可选值：left, center, right
    },
  },
  methods: {
    handleToggle() {
      // 仅在允许交互时触发 toggle 事件
      if (this.interactive) {
        this.$emit("toggle", this.id); // 触发 toggle 事件，传递 id
      }
    },
  },
};
</script>

 

<style scoped>
.data-card {
  width: 100%; /* 卡片宽度占满父容器 */
  height: 100px; /* 固定高度，防止高度变化 */
  margin: 8px 0; /* 卡片之间的间距 */
  background: rgba(255, 255, 255, 0.1); /* 半透明背景 */
  border: 1px solid rgba(255, 255, 255, 0.3); /* 边框 */
  border-radius: 5px; /* 圆角 */
  text-align: center; /* 内容居中 */
  display: flex;
  flex-direction: column;
  justify-content: center; /* 垂直居中 */
  align-items: center; /* 水平居中 */
  padding: 0px; /* 内边距 */
  box-sizing: border-box; /* 确保 padding 不影响卡片大小 */
}

.data-card-title {
  margin: 0; /* 移除默认 margin */
  font-weight: normal; /* 移除默认加粗 */
  line-height: 1; /* 确保文本行高一致，避免撑开高度 */
}

.data-card-value {
  margin: 5px 0 0 0; /* 数值与标题之间的间距 */
  line-height: 1; /* 确保文本行高一致，避免撑开高度 */
}
</style>