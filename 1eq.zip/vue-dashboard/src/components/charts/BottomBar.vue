<!-- src/views/UserDashboard/components/UeBottomBar.vue -->
<!-- <template>
    <div class="charts-container">
      <div class="chart-item">
        <LineChart
          title="下行RLC"
          :xData="rlcTime"
          :yData="downlinkRLC"
          color="#37a2da"
        />
      </div>
      <div class="chart-item">
        <LineChart
          title="上行RLC"
          :xData="rlcTime"
          :yData="uplinkRLC"
          color="#67e0e3"
        />
      </div>
      <div class="chart-item">
        <LineChart
          title="CPU 使用率"
          :xData="cpuTime"
          :yData="cpuUsage"
          color="#fd666d"
        />
      </div>
      <div class="chart-item">
        <LineChart
          title="内存使用量"
          :xData="memoryTime"
          :yData="memoryUsage"
          color="#67e0e3"
        />
      </div>
    </div>
  </template>

  <script lang="ts">
  import { defineComponent, computed } from 'vue';
  import { useUeStore } from '@/store/modules/ueModule';
  import LineChart from '@/components/charts/LineChart.vue';

  export default defineComponent({
    name: 'UserDashboardCharts',
    components: {
      LineChart,
    },
    setup() {
      const userStore = useUeStore();

      const rlcTime = computed(() => userStore.rlcTime);
      const downlinkRLC = computed(() => userStore.downlinkRLC);
      const uplinkRLC = computed(() => userStore.uplinkRLC);
      const cpuTime = computed(() => userStore.cpuTime);
      const cpuUsage = computed(() => userStore.cpuUsage);
      const memoryTime = computed(() => userStore.memoryTime);
      const memoryUsage = computed(() => userStore.memoryUsage);

      return {
        rlcTime,
        downlinkRLC,
        uplinkRLC,
        cpuTime,
        cpuUsage,
        memoryTime,
        memoryUsage,
      };
    },
  });
  </script>

  <style scoped>
  .charts-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    width: 100%;
    height: 100%;
  }

  .chart-item {
    flex: 1 1 calc(50% - 20px); /* 两列布局 */
    min-width: 300px;
    height: 100%;
  }
  </style> -->
