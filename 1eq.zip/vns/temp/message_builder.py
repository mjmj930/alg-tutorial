# message_builder.py

import struct
from message_constants import FIXED_FLAG

def build_om_app_header(total_len: int, fixed_flag: int = FIXED_FLAG) -> bytes:
    """
    构建 OM_APP_MSG_HEADER，包含:
      VOS_UINT16 (固定标识符) + VOS_UINT16 (消息体长度，不含自身)
    大端序
    """
    return struct.pack("!HH", fixed_flag, total_len)

def build_app_header():
    """
    构建示例化的 APP_MSG_HEADER，
    按协议需要包含: CB_MSG_HEADER(12字节) + 2个VOS_UINT16 + 3个VOS_UINT32
    这里只是示例演示，实际需要根据业务补足正确参数
    """
    cb_msg_header = b'\x00' * 12  # 占位
    # 假设 2个VOS_UINT16, 3个VOS_UINT32 都是0
    return struct.pack("!12sHHIII", cb_msg_header, 0, 0, 0, 0, 0)

def build_shakehand_req(msg_id: int, aucPara: int = 0, ulCnntInfo: int = 0) -> bytes:
    """
    构建握手请求消息( SHAKEHAND_REQ )
    msg_id: 例如 0x30101679
    aucPara, ulCnntInfo: 消息体参数
    """
    # 1) APP_MSG_HEADER
    app_header = build_app_header()

    # 2) 消息体(示例: 2*32位)
    body = struct.pack("!II", aucPara, ulCnntInfo)

    # 3) 计算body长度(不含 OM_APP_MSG_HEADER 自身)
    #    total_len = MsgId(4字节) + APP_MSG_HEADER(28字节) + body(8字节)
    total_len = 4 + len(app_header) + len(body)

    # 4) 拼装 OM_APP_MSG_HEADER
    om_app_header = build_om_app_header(total_len)

    # 5) MsgId (4字节,大端)
    msg_id_pack = struct.pack("!I", msg_id)

    return om_app_header + msg_id_pack + app_header + body

def parse_shakehand_cnf(data: bytes) -> dict:
    """
    解析握手确认消息( SHAKEHAND_CNF )，返回结构化字典
    """
    if len(data) < 8:
        return {"error": "data length too short"}

    # 前4字节: fixed_flag + total_len
    fixed_flag, total_len = struct.unpack("!HH", data[:4])
    msg_id = struct.unpack("!I", data[4:8])[0]

    # 后续为 APP_MSG_HEADER(28字节) + 8字节消息体( aucPara + ulCnntInfo )
    expected_full_len = 8 + 28 + 8  # 8=OM_APP+MsgId, 28=APP_HEADER, 8=body
    if len(data) < expected_full_len:
        return {"error": "data length not match expected"}

    # 解析 body
    body_offset = 8 + 28
    aucPara, ulCnntInfo = struct.unpack("!II", data[body_offset:body_offset + 8])

    return {
        "fixed_flag": hex(fixed_flag),
        "total_len": total_len,
        "msg_id": hex(msg_id),
        "aucPara": aucPara,
        "ulCnntInfo": ulCnntInfo,
    }

#######################################
# 心跳、订阅等同理 build_xxx_req / parse_xxx_cnf
#######################################

def build_heartbeat_req(msg_id: int) -> bytes:
    """
    构建心跳请求 HEARTBEAT_REQ
    """
    app_header = build_app_header()
    body = struct.pack("!I", 0)  # 假设 body 里一个 32位保留字段
    # length = 4(msgId) + 28(app_header) + 4(body) = 36
    total_len = 4 + len(app_header) + len(body)
    om_app_header = build_om_app_header(total_len)
    msg_id_pack = struct.pack("!I", msg_id)
    return om_app_header + msg_id_pack + app_header + body

def parse_heartbeat_cnf(data: bytes) -> dict:
    """
    解析心跳确认消息 HEARTBEAT_CNF
    """
    if len(data) < 8:
        return {"error": "data length too short"}

    fixed_flag, total_len = struct.unpack("!HH", data[:4])
    msg_id = struct.unpack("!I", data[4:8])[0]
    return {
        "fixed_flag": hex(fixed_flag),
        "total_len": total_len,
        "msg_id": hex(msg_id)
    }

def build_register_req(msg_id: int, register_msg_id: int, is_register: int = 1) -> bytes:
    """
    构建订阅请求 REGISTER_REQ
    register_msg_id: 要订阅的 IND 消息ID
    is_register: 0=取消订阅, 1=订阅
    """
    app_header = build_app_header()
    body = struct.pack("!II", register_msg_id, is_register)  # for example
    total_len = 4 + len(app_header) + len(body)
    om_app_header = build_om_app_header(total_len)
    msg_id_pack = struct.pack("!I", msg_id)
    return om_app_header + msg_id_pack + app_header + body

def parse_register_cnf(data: bytes) -> dict:
    """
    解析订阅确认消息 REGISTER_CNF
    ( result, reserve )
    """
    if len(data) < 8:
        return {"error": "data length too short"}

    fixed_flag, total_len = struct.unpack("!HH", data[:4])
    msg_id = struct.unpack("!I", data[4:8])[0]

    # body(8字节): result+reserve
    body_offset = 8 + 28  # 8=OM_APP+MsgId,28=APP_HEADER
    if len(data) < body_offset + 8:
        return {"error": "data length not match expected"}

    result, reserve = struct.unpack("!II", data[body_offset:body_offset+8])

    return {
        "fixed_flag": hex(fixed_flag),
        "total_len": total_len,
        "msg_id": hex(msg_id),
        "result": result,
        "reserve": reserve
    }

def parse_ind_message(data: bytes) -> dict:
    """
    解析上报消息( IND ), 仅示例
    根据协议解析 body 中的各参数
    """
    # 解析 OM_APP_HEADER + msgId + APP_HEADER + ...
    # 根据协议提取需要信息
    # 这里做简单示例...
    return {"data": data.hex()}