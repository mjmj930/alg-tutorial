<template>
  <div class="container">
    <h1 class="title">网络吞吐量监控</h1>
    
    <div ref="chartRef" class="dashboard"></div>
    
    <div class="data-display">
      <div class="data-value" :class="currentMode">{{ currentSpeed }} Mbps</div>
      <div class="data-label" :class="currentMode" @click="switchMode">
        {{ currentLabel }}
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'
import * as echarts from 'echarts'
import { useSpeedStore } from '@/store/speedStore'

const chartRef = ref<HTMLElement | null>(null)
const myChart = ref<any>(null)
const speedStore = useSpeedStore()

// 基础配置
const baseOption = {
  backgroundColor: 'transparent',
  tooltip: {
    formatter: '{a} <br/>{b} : {c} Mbps'
  },
  series: [
    {
      name: '速度',
      type: 'gauge',
      center: ['50%', '55%'],
      radius: '90%',
      splitNumber: 10,
      axisLine: {
        lineStyle: {
          width: 20,
          color: [
            [0.3, '#0e1c52'],
            [0.7, '#1a3aaa'],
            [1, '#2a5cd4']
          ]
        }
      },
      axisTick: {
        length: 12,
        lineStyle: {
          color: 'auto',
          width: 2
        }
      },
      splitLine: {
        length: 20,
        lineStyle: {
          color: 'auto',
          width: 3
        }
      },
      axisLabel: {
        color: '#7fdbff',
        distance: -30,
        fontSize: 12,
        formatter: function(value: number) {
          if (value % 20 === 0) return value
          return ''
        }
      },
      detail: {
        valueAnimation: true,
        formatter: '{value} Mbps',
        fontSize: 20,
        offsetCenter: [0, '70%']
      },
      data: [
        {
          value: 0,
          name: '上行'
        }
      ],
      title: {
        offsetCenter: [0, '-20%'],
        color: '#7fdbff',
        fontSize: 16
      },
      pointer: {
        width: 6,
        length: '70%'
      },
      animationDuration: 2000
    }
  ]
}

// 上行配置
const uploadOption = {
  series: [
    {
      min: 0,
      max: 100,
      axisLine: {
        lineStyle: {
          color: [
            [0.3, '#0e1c52'],
            [0.7, '#1a3aaa'],
            [1, '#2a5cd4']
          ]
        }
      },
      detail: {
        color: '#00f2ff'
      },
      pointer: {
        itemStyle: {
          color: '#00f2ff'
        }
      },
      title: {
        color: '#7fdbff'
      }
    }
  ]
}

// 下行配置
const downloadOption = {
  series: [
    {
      min: 0,
      max: 200,
      axisLine: {
        lineStyle: {
          color: [
            [0.3, '#520e1c'],
            [0.7, '#aa1a3a'],
            [1, '#d42a5c']
          ]
        }
      },
      detail: {
        color: '#ff00f2'
      },
      pointer: {
        itemStyle: {
          color: '#ff00f2'
        }
      },
      title: {
        color: '#ff7fdb'
      },
      data: [
        {
          value: 0,
          name: '下行'
        }
      ]
    }
  ]
}

// 合并配置
const getCurrentOption = () => {
  const option = JSON.parse(JSON.stringify(baseOption))
  const modeOption = speedStore.currentMode === 'upload' ? uploadOption : downloadOption
  
  // 深度合并配置
  Object.assign(option.series[0], modeOption.series[0])
  option.series[0].data[0].value = speedStore.currentSpeed
  option.series[0].data[0].name = speedStore.currentMode === 'upload' ? '上行' : '下行'
  option.series[0].detail.color = speedStore.currentColor
  
  return option
}

// 更新图表
const updateChart = () => {
  if (myChart.value) {
    myChart.value.setOption(getCurrentOption())
  }
}

// 切换模式
const switchMode = () => {
  speedStore.switchMode()
  updateChart()
}

// 更新数据
let updateInterval: number | null = null

const startUpdate = () => {
  updateInterval = setInterval(() => {
    speedStore.updateSpeeds()
    updateChart()
  }, 2000) as unknown as number
}

const stopUpdate = () => {
  if (updateInterval) {
    clearInterval(updateInterval)
    updateInterval = null
  }
}

onMounted(() => {
  if (chartRef.value) {
    myChart.value = echarts.init(chartRef.value)
    myChart.value.setOption(getCurrentOption())
    
    // 初始更新数据
    speedStore.updateSpeeds()
    updateChart()
    
    // 开始定时更新
    startUpdate()
    
    // 监听窗口大小变化
    window.addEventListener('resize', () => {
      myChart.value?.resize()
    })
  }
})

onUnmounted(() => {
  stopUpdate()
  myChart.value?.dispose()
  window.removeEventListener('resize', () => {
    myChart.value?.resize()
  })
})

// 监听模式变化
watch(() => speedStore.currentMode, () => {
  updateChart()
})
</script>

<style scoped>
.container {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.dashboard {
  width: 600px;
  height: 500px;
}

.title {
  text-align: center;
  margin-bottom: 20px;
  font-size: 24px;
  color: #00f2ff;
  text-shadow: 0 0 10px rgba(0, 242, 255, 0.5);
}

.data-display {
  text-align: center;
  margin-top: 20px;
}

.data-value {
  font-size: 28px;
  margin-bottom: 10px;
  transition: color 0.3s;
}

.data-label {
  font-size: 16px;
  cursor: pointer;
  padding: 8px 20px;
  border-radius: 20px;
  transition: all 0.3s;
  display: inline-block;
  background: rgba(255, 255, 255, 0.1);
}

.data-label:hover {
  background: rgba(255, 255, 255, 0.15);
}

.upload {
  color: #00f2ff;
}

.download {
  color: #ff00f2;
}
</style>    