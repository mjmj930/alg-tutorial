import { defineStore } from 'pinia'
import { ref, computed, watch } from 'vue'
import axios from 'axios'

// 设备基本信息类型
export interface DeviceBasicInfo {
  id: string
  name: string
  ip: string
  status: 'online' | 'offline'
  traffic: number
  responseTime: number
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  onlineTime: number
}

// 流量历史记录类型
export interface TrafficHistory {
  time: string
  incoming: number
  outgoing: number
}

// 设备详细信息类型
export interface DeviceDetail extends DeviceBasicInfo {
  trafficHistory: TrafficHistory[]
  events: DeviceEvent[]
}

// 设备事件类型
export interface DeviceEvent {
  type: 'info' | 'warning' | 'error'
  message: string
  timestamp: string
}

export const useDevicesStore = defineStore('devices', () => {
  // 设备列表
  const devices = ref<DeviceBasicInfo[]>([])
  
  // 获取设备列表
  const fetchDevices = async () => {
    try {
      const response = await axios.get('/api/devices')
      devices.value = response.data
    } catch (error) {
      console.error('获取设备列表失败:', error)
      // 这里可以添加错误处理逻辑
    }
  }
  
  // 获取单个设备详情
  const fetchDeviceDetail = async (deviceId: string) => {
    try {
      const response = await axios.get(`/api/devices/${deviceId}/detail`)
      // 更新设备列表中的设备信息
      const index = devices.value.findIndex(d => d.id === deviceId)
      if (index !== -1) {
        devices.value[index] = response.data
      }
      return response.data
    } catch (error) {
      console.error('获取设备详情失败:', error)
      // 这里可以添加错误处理逻辑
      throw error
    }
  }
  
  // 通过ID获取设备
  const getDeviceById = (deviceId: string) => {
    return devices.value.find(d => d.id === deviceId)
  }
  
  // 设备总数
  const totalDevices = computed(() => devices.value.length)
  
  // 在线设备数量
  const onlineDevices = computed(() => 
    devices.value.filter(device => device.status === 'online').length
  )
  
  // 离线设备数量
  const offlineDevices = computed(() => 
    devices.value.filter(device => device.status === 'offline').length
  )
  
  // 模拟实时数据更新
  const startRealTimeUpdates = () => {
    const interval = setInterval(() => {
      if (devices.value.length > 0) {
        // 随机选择几个设备更新数据
        const updateCount = Math.floor(Math.random() * 3) + 1
        for (let i = 0; i < updateCount; i++) {
          const randomIndex = Math.floor(Math.random() * devices.value.length)
          const device = devices.value[randomIndex]
          
          // 更新设备数据
          devices.value[randomIndex] = {
            ...device,
            cpuUsage: Math.floor(Math.random() * 100),
            memoryUsage: Math.floor(Math.random() * 100),
            traffic: Math.floor(Math.random() * 100),
            responseTime: Math.floor(Math.random() * 100) + 10
          }
        }
      }
    }, 5000)
    
    // 返回清理函数
    return () => clearInterval(interval)
  }
  
  return {
    devices,
    totalDevices,
    onlineDevices,
    offlineDevices,
    fetchDevices,
    fetchDeviceDetail,
    getDeviceById,
    startRealTimeUpdates
  }
})  