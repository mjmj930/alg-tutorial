// src/socket/socket.ts
import { io, Socket } from 'socket.io-client'
import { useDataStore } from './stores/dataStore'

// 建立 Socket.IO 连接（注意修改为后端实际地址及端口）
const socket: Socket = io("http://localhost:5000")

socket.on('connect', () => {
  console.log("Connected to server")
})

socket.on('data_update', (data: { [key: string]: number }) => {
  // 获取 Pinia store 实例，并更新数据
  const store = useDataStore()
  store.updateData(data)
})

export default socket
