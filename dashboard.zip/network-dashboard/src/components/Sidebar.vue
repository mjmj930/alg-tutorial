<template>
    <aside class="sidebar">
      <div class="logo">
        <h2>网络监控系统</h2>
      </div>
      <nav class="nav-menu">
        <router-link to="/dashboard" class="nav-item">
          <span class="icon">📊</span>
          <span class="text">仪表盘</span>
        </router-link>
        <router-link to="/devices" class="nav-item">
          <span class="icon">📱</span>
          <span class="text">设备管理</span>
        </router-link>
        <router-link to="/settings" class="nav-item">
          <span class="icon">⚙️</span>
          <span class="text">系统设置</span>
        </router-link>
        <router-link to="/alerts" class="nav-item">
          <span class="icon">🔔</span>
          <span class="text">告警中心</span>
        </router-link>
        <router-link to="/reports" class="nav-item">
          <span class="icon">📄</span>
          <span class="text">分析报告</span>
        </router-link>
      </nav>
      <div class="sidebar-footer">
        <div class="status-indicator">
          <span class="indicator-dot"></span>
          <span>系统运行正常</span>
        </div>
      </div>
    </aside>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue'
  
  export default defineComponent({
    name: 'Sidebar'
  })
  </script>
  
  <style scoped>
  .sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    background: rgba(16, 31, 63, 0.9);
    backdrop-filter: blur(10px);
    border-right: 1px solid rgba(79, 172, 254, 0.2);
    display: flex;
    flex-direction: column;
    z-index: 100;
    transition: all 0.3s;
  }
  
  .logo {
    padding: 20px;
    text-align: center;
    border-bottom: 1px solid rgba(79, 172, 254, 0.1);
  }
  
  .logo h2 {
    margin: 0;
    color: #4facfe;
    font-size: 1.5rem;
    background: linear-gradient(90deg, #00f2fe, #4facfe);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  
  .nav-menu {
    flex: 1;
    padding: 20px 0;
    overflow-y: auto;
  }
  
  .nav-item {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    margin: 5px 10px;
    color: #8a9bb8;
    text-decoration: none;
    border-radius: 6px;
    transition: all 0.3s;
  }
  
  .nav-item:hover {
    background: rgba(79, 172, 254, 0.1);
    color: #4facfe;
  }
  
  .nav-item.router-link-active {
    background: rgba(79, 172, 254, 0.2);
    color: #4facfe;
  }
  
  .icon {
    font-size: 1.2rem;
    margin-right: 10px;
  }
  
  .text {
    font-size: 0.95rem;
  }
  
  .sidebar-footer {
    padding: 15px;
    border-top: 1px solid rgba(79, 172, 254, 0.1);
  }
  
  .status-indicator {
    display: flex;
    align-items: center;
    font-size: 0.85rem;
    color: #8a9bb8;
  }
  
  .indicator-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #52c41a;
    margin-right: 8px;
    box-shadow: 0 0 10px #52c41a;
  }
  
  @media (max-width: 992px) {
    .sidebar {
      transform: translateX(-100%);
    }
    
    .sidebar.active {
      transform: translateX(0);
    }
  }
  </style>