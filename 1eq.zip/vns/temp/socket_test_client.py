import socket
import struct

# 服务端地址和端口
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8080


# 构造消息
def build_message(msg_id, body):
    """
    构建消息，包含消息头和消息体
    :param msg_id: int - 消息ID
    :param body: str - 消息体内容
    :return: bytes - 完整的消息
    """
    body_bytes = body.encode('utf-8')
    body_length = len(body_bytes)
    header = struct.pack('!I I', msg_id, body_length)  # 大端字节序
    return header + body_bytes


# 启动客户端
def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    print(f"Connected to server at {SERVER_HOST}:{SERVER_PORT}")

    while True:
        print("\nChoose a message to send:")
        print("1. Downlink Data (MsgID=0x01020304)")
        print("2. Uplink Data (MsgID=0x05060708)")
        print("3. Custom Message")
        print("4. Exit")
        choice = input("Enter your choice (1-4): ")

        if choice == '1':
            # 下行数据
            message = build_message(0x01020304, "Hello, Base Station!")
        elif choice == '2':
            # 上行数据
            message = build_message(0x05060708, "Uplink Data from Client")
        elif choice == '3':
            # 自定义消息
            custom_id = int(input("Enter custom MsgID (in hex, e.g., 0x12345678): "), 16)
            custom_body = input("Enter custom message body: ")
            message = build_message(custom_id, custom_body)
        elif choice == '4':
            print("Closing connection...")
            break
        else:
            print("Invalid choice, try again.")
            continue

        # 发送消息
        print(f"Sending message: {message.hex()}")
        client_socket.send(message)

        # 接收响应
        response_header = client_socket.recv(8)  # 先接收8字节的响应头
        response_id, response_length = struct.unpack('!I I', response_header)
        response_body = client_socket.recv(response_length)  # 根据长度接收响应体
        print(f"Received Response: MsgID={hex(response_id)}, Body={response_body.decode('utf-8')}")

    client_socket.close()


if __name__ == "__main__":
    start_client()
