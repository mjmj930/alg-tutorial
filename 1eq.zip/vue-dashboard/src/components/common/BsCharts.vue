<!-- src/views/BsDashboard/components/BsCharts.vue -->
<!-- <template>
    <BarChart
      title="基站特定数据"
      :xData="xData"
      :yData="yData"
      color="#ffa500"
    />
  </template>

  <script lang="ts">
  import { defineComponent, computed } from 'vue';
  import BarChart from '@/components/charts/BarChart.vue';
  import { useBsStore } from '@/store/modules/bsModule.ts';

  export default defineComponent({
    name: 'BsSpecificChart',
    components: {
      BarChart,
    },
    setup() {
      const bsStore = useBsStore();

      const xData = computed(() => bsStore.rlctime);
      const yData = computed(() => bsStore.downlinkRLC);

      return {
        xData,
        yData,
      };
    },
  });
  </script>

  <style scoped>
  /* 根据需要添加样式 */
  </style> -->
