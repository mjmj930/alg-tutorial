<!-- src/views/BsDashboard/components/BsBottomBar.vue -->
<template>
    <div class="charts-container">
      <LineChart
        title="下行RLC"
        :xData="rlctime"
        :yData="downlinkRLC"
        color="#37a2da"
      />
      <LineChart
        title="上行RLC"
        :xData="rlctime"
        :yData="uplinkRLC"
        color="#67e0e3"
      />
    </div>
  </template>

  <script lang="ts">
  import { defineComponent, computed } from 'vue';
  import { useBsStore } from '@/store/modules/bsModule.ts';
  import LineChart from '@/components/charts/ULThroughputChart.vue';

  export default defineComponent({
    name: 'BsDashboardCharts',
    components: {
      LineChart,
    },
    setup() {
      const bsStore = useBsStore();

      const rlctime = computed(() => bsStore.rlctime);
      const downlinkRLC = computed(() => bsStore.downlinkRLC);
      const uplinkRLC = computed(() => bsStore.uplinkRLC);

      return {
        rlctime,
        downlinkRLC,
        uplinkRLC,
      };
    },
  });
  </script>

  <style scoped>
  .charts-container {
    display: flex;
    flex-direction: row;
    gap: 20px;
    height: 100%;
  }
  </style>
