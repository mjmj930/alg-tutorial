import { createRouter, createWebHistory } from 'vue-router'
import DeviceList from '@/components/DeviceList.vue'
import DeviceDetail from '@/components/DeviceDetail.vue'

const routes = [
  {
    path: '/',
    name: 'DeviceList',
    component: DeviceList
  },
  {
    path: '/device/:id',
    name: 'DeviceDetail',
    component: DeviceDetail,
    props: true
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior(to, from, savedPosition) {
    // 始终滚动到顶部
    return { top: 0 }
  }
})

export default router  