import mitt from 'mitt';

type Events = {
  // 定义事件类型
  chartDataUpdated: void;
  toggleDataDisplay: boolean; // 添加新事件，携带一个布尔值表示是否显示上行数据
};

const emitter = mitt<Events>();

export default emitter;