// src/store/dataStore.ts
import { defineStore } from 'pinia'
import { ref } from 'vue'

export interface IData {
  UplinkThroughput: number | undefined
  UplinkSINR: number | undefined
  UplinkMCS: number | undefined
  UplinkTxPower: number | undefined
  UplinkRetransmissionRate: number | undefined
  DownlinkThroughput: number | undefined
  DownlinkSINR: number | undefined
  DownlinkMCS: number | undefined
  RSRP: number | undefined
  T1UplinkThroughput: number | undefined
  T1UplinkSINR: number | undefined
  T1UplinkMCS: number | undefined
  T1UplinkTxPower: number | undefined
  T1UplinkRetransmissionRate: number | undefined
  T1DownlinkThroughput: number | undefined
  T1DownlinkSINR: number | undefined
  T1DownlinkMCS: number | undefined
  T1RSRP: number | undefined
}

export const useDataStore = defineStore('data', () => {
  // 初始数据为空，接收到数据后更新
  const data = ref<IData | null>(null)

  function updateData(newData: Partial<IData>) {
    data.value = { ...data.value, ...newData } as IData
  }
  

  return { data, updateData }
})
