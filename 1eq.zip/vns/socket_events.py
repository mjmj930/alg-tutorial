import time
from threading import Thread
from flask_socketio import SocketIO
from data_generator import generate_ue_data, generate_bs_data

# 创建一个 Socket.IO 实例
socketio = SocketIO()

# 数据发送线程
def send_data():
    while True:
        # 生成模拟数据
        ue_data = generate_ue_data()
        bs_data = generate_bs_data()

        # 包装成完整的 payload
        data_payload = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),  # 当前时间戳
            "data": {
                "ueData": ue_data,
                "bsData": bs_data,
            },
        }

        # 通过 Socket.IO 发送数据
        socketio.emit("update_data", data_payload)

        # 每秒发送一次
        time.sleep(1)

# 启动数据发送线程
def start_sending_data():
    thread = Thread(target=send_data)
    thread.daemon = True  # 设置为守护线程
    thread.start()