# client_socket.py

import socket
import logging

from config import Config
from message_constants import (
    SHAKEHAND_REQ_ID,
    HEARTBEAT_REQ_ID,
    REGISTER_REQ_ID
)
from message_builder import (
    build_shakehand_req, parse_shakehand_cnf,
    build_heartbeat_req, parse_heartbeat_cnf,
    build_register_req, parse_register_cnf,
    parse_ind_message
)


class UESocketClient:
    def __init__(self):
        self.host = Config.UE_SERVER_HOST
        self.port = Config.UE_SERVER_PORT
        self.sock = None
        self.logger = logging.getLogger("UESocketClient")

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(Config.SOCKET_TIMEOUT)
        self.sock.connect((self.host, self.port))
        self.logger.info(f"Connected to {self.host}:{self.port}")

    def close(self):
        if self.sock:
            self.sock.close()
            self.sock = None
            self.logger.info("Socket closed.")

    def send_data(self, data: bytes):
        if not self.sock:
            raise ConnectionError("Socket not connected.")
        self.logger.debug(f"Sending data: {data.hex()}")
        self.sock.sendall(data)

    def recv_data(self) -> bytes:
        if not self.sock:
            raise ConnectionError("Socket not connected.")
        data = self.sock.recv(Config.RECV_BUF_SIZE)
        self.logger.debug(f"Received data({len(data)} bytes): {data.hex()}")
        return data

    def shakehand(self, aucPara=0, ulCnntInfo=0) -> dict:
        """
        1) 发送握手请求 (SHAKEHAND_REQ)
        2) 接收并解析握手应答 (SHAKEHAND_CNF)
        """
        if not self.sock:
            self.connect()
        req_packet = build_shakehand_req(SHAKEHAND_REQ_ID, aucPara, ulCnntInfo)
        self.send_data(req_packet)

        resp = self.recv_data()
        parsed = parse_shakehand_cnf(resp)
        if "error" in parsed:
            self.logger.error(f"Shakehand parse error: {parsed}")
        else:
            self.logger.info(f"Shakehand success: {parsed}")
        return parsed

    def heartbeat(self) -> dict:
        """
        发送心跳请求 HEARTBEAT_REQ, 接收确认 HEARTBEAT_CNF
        """
        req_packet = build_heartbeat_req(HEARTBEAT_REQ_ID)
        self.send_data(req_packet)
        resp = self.recv_data()
        parsed = parse_heartbeat_cnf(resp)
        if "error" in parsed:
            self.logger.error(f"Heartbeat parse error: {parsed}")
        else:
            self.logger.info(f"Heartbeat confirmed: {parsed}")
        return parsed

    def subscribe(self, register_msg_id: int, is_register=1) -> dict:
        """
        发送订阅请求 REGISTER_REQ, 接收确认 REGISTER_CNF
        """
        req_packet = build_register_req(REGISTER_REQ_ID, register_msg_id, is_register)
        self.send_data(req_packet)
        resp = self.recv_data()
        parsed = parse_register_cnf(resp)
        if "error" in parsed:
            self.logger.error(f"Subscribe parse error: {parsed}")
        else:
            self.logger.info(f"Subscribe confirmed: {parsed}")
        return parsed

    def receive_ind(self) -> dict:
        """
        演示如何接收 UE 的上报(IND)消息;
        实际可能需要长连接、循环监听等方式。
        """
        resp = self.recv_data()
        parsed = parse_ind_message(resp)
        self.logger.info(f"IND received: {parsed}")
        return parsed
