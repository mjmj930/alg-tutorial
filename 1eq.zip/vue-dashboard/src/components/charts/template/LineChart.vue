<template>
  <div id="chart" ref="chartRef" class="chart"></div>
</template>

<script lang="ts">
import { defineComponent, onMounted, onBeforeUnmount, ref } from "vue";
import * as echarts from "echarts";

export default defineComponent({
  name: "",
  setup() {
    const chartRef = ref<HTMLDivElement | null>(null); // 引用图表 DOM 容器
    let chartInstance: echarts.ECharts | null = null; // 图表实例
    let interval: number | undefined;

    // 初始数据
    const initialData = {
      categories: [] as string[], // 横轴时间数据
      data1: [] as number[],      // 数据1
      // data2: [] as number[],      // 数据2
    };

    // 初始化图表
    const initChart = () => {
      if (!chartRef.value) return;

      // 创建图表实例
      chartInstance = echarts.init(chartRef.value);

      // 配置选项
      const option: echarts.EChartsOption = {
        title: {
          text: "动态曲线面积图 - 实时时间",
          left: "center",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross",
            label: {
              backgroundColor: "#6a7985",
            },
          },
        },
        legend: {
          // data: ["数据1", "数据2"],
          data: ["数据1"],
          top: "10%",
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: initialData.categories,
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "DataName",
            type: "line",
            smooth: true,
            areaStyle: { opacity: 0.5 },
            emphasis: { focus: "series" },
            data: initialData.data1,
            itemStyle: { color: "#5470C6" },
          },
          // {
          //   name: "数据2",
          //   type: "line",
          //   smooth: true,
          //   areaStyle: { opacity: 0.5 },
          //   emphasis: { focus: "series" },
          //   data: initialData.data2,
          //   itemStyle: { color: "#91CC75" },
          // },
        ],
      };

      // 设置图表选项
      chartInstance.setOption(option);

      // 动态更新数据
      interval = window.setInterval(() => {
        updateData();
      }, 1000);

      // 窗口大小变化时自适应
      window.addEventListener("resize", resizeChart);
    };

    // 更新图表数据
    const updateData = () => {
      const now = new Date();
      const timeString = `${now.getHours().toString().padStart(2, "0")}:${now
          .getMinutes()
          .toString()
          .padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;

      // 随机生成新数据
      const newData1 = Math.floor(Math.random() * 300);
      // const newData2 = Math.floor(Math.random() * 400);

      // 更新初始数据
      initialData.categories.push(timeString);
      initialData.data1.push(newData1);
      // initialData.data2.push(newData2);

      // 保持最多显示 10 个点
      if (initialData.categories.length > 10) {
        initialData.categories.shift();
        initialData.data1.shift();
        // initialData.data2.shift();
      }

      // 更新图表
      chartInstance?.setOption({
        xAxis: {
          data: initialData.categories,
        },
        series: [
          {
            data: initialData.data1,
          },
          // {
          //   data: initialData.data2,
          // },
        ],
      });
    };

    // 图表响应式调整大小
    const resizeChart = () => {
      chartInstance?.resize();
    };

    // 销毁图表
    const destroyChart = () => {
      if (chartInstance) {
        chartInstance.dispose();
        chartInstance = null;
      }
      if (interval) {
        clearInterval(interval);
      }
      window.removeEventListener("resize", resizeChart);
    };

    // 挂载和卸载生命周期
    onMounted(() => {
      initChart();
    });

    onBeforeUnmount(() => {
      destroyChart();
    });

    return {
      chartRef,
    };
  },
});
</script>

<style scoped>
.chart {
  width: 100%;
  max-width: 800px;
  height: 400px;
  margin: 0 auto;
}
</style>
