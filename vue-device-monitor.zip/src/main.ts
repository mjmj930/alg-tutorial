import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { createPinia } from 'pinia'
import './assets/main.css'

// 导入Chart.js
import 'chart.js/auto'

// 创建应用实例
const app = createApp(App)

// 使用Pinia状态管理
const pinia = createPinia()
app.use(pinia)

// 使用路由
app.use(router)

// 挂载应用
app.mount('#app')

// 启动实时数据更新
const devicesStore = useDevicesStore(pinia)
const stopRealTimeUpdates = devicesStore.startRealTimeUpdates()

// 在应用卸载时停止实时更新
app.unmount = () => {
  stopRealTimeUpdates()
  app._container.innerHTML = ''
}  