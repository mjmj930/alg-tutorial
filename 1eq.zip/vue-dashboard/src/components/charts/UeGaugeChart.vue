<template>
    <div id="gauge-chart" class="gauge-chart gauge-chart-global" ref="chartRef"></div>
  </template>
  
  <script lang="ts">
  import { defineComponent, ref, onMounted, onBeforeUnmount } from "vue";
  import * as echarts from "echarts";
  
  export default defineComponent({
    name: "GaugeChart",
    setup() {
      const chartRef = ref<HTMLDivElement | null>(null); // DOM 容器引用
      let chartInstance: echarts.ECharts | null = null; // ECharts 实例
      let interval: number | undefined;
  
      // 初始化图表
      const initChart = () => {
        if (!chartRef.value) return;
  
        // 创建 ECharts 实例
        chartInstance = echarts.init(chartRef.value);
  
        // 配置仪表盘选项
        const option: echarts.EChartsOption = {
          title: {
            text: "",
            left: "center",
            top: "5%",
            textStyle: {
              color: "#333",
              fontSize: 24,
              fontWeight: "bold",
            },
          },
          series: [
            {
              type: "gauge",
              center: ["50%", "65%"],
              startAngle: 200,
              endAngle: -20,
              min: 0,
              max: 60,
              splitNumber: 12,
              itemStyle: {
                color: "rgb(51, 62, 245,0.3)",
              },
              progress: {
                show: true,
                width: 30,
              },
              pointer: {
                show: false,
              },
              axisLine: {
                lineStyle: {
                  width: 30,
                },
              },
              axisTick: {
                distance: -45,
                splitNumber: 5,
                lineStyle: {
                  width: 2,
                  color: "rgb(97, 105, 232,0.6)", // 调整刻度线颜色
                },
              },
              splitLine: {
                distance: -52,
                length: 14,
                lineStyle: {
                  width: 3,
                  color: "#333", // 调整分隔线颜色
                },
              },
              axisLabel: {
                distance: -20,
                color: "#3742f0", // 调整刻度盘字体颜色
                fontSize: 16,
              },
              anchor: {
                show: false,
              },
              title: {
                show: false,
              },
              detail: {
                valueAnimation: true,
                width: "60%",
                lineHeight: 20,
                borderRadius: 8,
                offsetCenter: [0, "-10%"],
                fontSize: 20, // 调整数值字体大小
                fontWeight: "bold",
                formatter: "{value} Mbps",
                color: "#dadbf0", // 调整数值颜色
              },
              data: [
                {
                  value: 20,
                },
              ],
            },
            {
              type: "gauge",
              center: ["50%", "65%"],
              startAngle: 200,
              endAngle: -20,
              min: 0,
              max: 60,
              itemStyle: {
                color: "#FD7347",
              },
              progress: {
                show: true,
                width: 8,
              },
              pointer: {
                show: false,
              },
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: false,
              },
              axisLabel: {
                show: false,
              },
              detail: {
                show: false,
              },
              data: [
                {
                  value: 20,
                },
              ],
            },
          ],
        };
  
        // 设置图表选项
        chartInstance.setOption(option);
  
        // 动态更新数据
        interval = window.setInterval(() => {
          updateChartData();
        }, 2000);
  
        // 响应式调整图表大小
        window.addEventListener("resize", resizeChart);
      };
  
      // 更新图表数据
      const updateChartData = () => {
        const randomValue = +(Math.random() * 60).toFixed(2); // 随机生成 0 ~ 60 范围内的数值
        chartInstance?.setOption({
          series: [
            { data: [{ value: randomValue }] },
            { data: [{ value: randomValue }] },
          ],
        });
      };
  
      // 图表响应式调整大小
      const resizeChart = () => {
        chartInstance?.resize();
      };
  
      // 销毁图表
      const destroyChart = () => {
        if (chartInstance) {
          chartInstance.dispose();
          chartInstance = null;
        }
        if (interval) {
          clearInterval(interval);
        }
        window.removeEventListener("resize", resizeChart);
      };
  
      // 生命周期管理
      onMounted(() => {
        initChart();
      });
  
      onBeforeUnmount(() => {
        destroyChart();
      });
  
      return {
        chartRef,
      };
    },
  });
  </script>
  
  <style scoped>
  .gauge-chart {
    width: 90%;
    max-width: 600px;
    height: 600px;
    margin: 0 auto;
  }
  
  .gauge-chart-global {
    width: 100%;
    max-width: 600px;
    height: 33%;
    margin: 0 auto;
  }
  </style>