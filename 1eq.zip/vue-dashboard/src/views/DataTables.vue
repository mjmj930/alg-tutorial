<!-- src/components/DataTables.vue -->

<template>
  <el-row :gutter="20" justify="center">
    <el-col :span="11">
      <el-card>
        <div slot="header">
          <span style="font-size: 18px; font-weight: bold; display: block; text-align: center;">BaseStaion Data</span>
        </div>
        <el-table :data="bsDataArray" style="width: 100%" size="small">
          <el-table-column prop="key" label="指标" width="200" />
          <el-table-column prop="value" label="数值" />
        </el-table>
      </el-card>
    </el-col>
    <el-col :span="11">
      <el-card>
        <div slot="header">
          <span style="font-size: 18px; font-weight: bold; display: block; text-align: center;">Test User Euqipment Data</span>
        </div>
        <el-table :data="tueDataArray" style="width: 100%" size="small">
          <el-table-column prop="key" label="指标" width="200" />
          <el-table-column prop="value" label="数值" />
          <el-table-column label="时间"> {{ timestamp }} </el-table-column>
        </el-table>
      </el-card>
    </el-col>
  </el-row>
</template>

<script lang="ts" setup>
import { computed, defineProps } from 'vue'
import { BsData, TueData } from './types'

interface Props {
  bsData: BsData | null
  tueData: TueData | null
  timestamp: string
}

const props = defineProps<Props>()

const bsDataArray = computed(() => {
  if (!props.bsData) return []
  return Object.entries(props.bsData).map(([key, value]) => ({
    key: formatKey(key),
    value: value
  }))
})

const tueDataArray = computed(() => {
  if (!props.tueData) return []
  return Object.entries(props.tueData).map(([key, value]) => ({
    key: formatKey(key),
    value: value
  }))
})

function formatKey(key: string): string {
  // 将下划线转换为空格并大写首字母
  return key.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase())
}
</script>
