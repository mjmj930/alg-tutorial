from flask import Flask
from flask_socketio import SocketIO
import eventlet

eventlet.monkey_patch()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")  # 允许跨域请求


def generate_data():
    import random
    while True:
        # 生成模拟数据，可以替换为实际数据逻辑
        data = {
            'UplinkThroughput': round(random.uniform(20, 60), 2),
            'UplinkSINR': round(random.uniform(8, 15), 2),
            'UplinkMCS': random.choice([2, 18]),
            'UplinkTxPower': round(random.uniform(4, 18), 2),
            'UplinkRetransmissionRate': round(random.uniform(0.75, 0.85), 2),
            'DownlinkThroughput': round(random.uniform(60, 75), 2),
            'DownlinkSINR': round(random.uniform(8, 12), 2),
            'DownlinkMCS': random.choice([15, 24]),
            'RSRP': round(random.uniform(-120, -110), 2),
            'T1UplinkThroughput': round(random.uniform(20, 60), 2),
            'T1UplinkSINR': round(random.uniform(8, 15), 2),
            'T1UplinkMCS': random.choice([2, 18]),
            'T1UplinkTxPower': round(random.uniform(4, 18), 2),
            'T1UplinkRetransmissionRate': round(random.uniform(0.75, 0.85), 2),
            'T1DownlinkThroughput': round(random.uniform(60, 75), 2),
            'T1DownlinkSINR': round(random.uniform(8, 12), 2),
            'T1DownlinkMCS': random.choice([15, 24]),
            'T1RSRP': round(random.uniform(-120, -110), 2),

        }
        print(data)
        socketio.emit('data_update', data)  # 通过事件名 'data_update' 发送数据
        socketio.sleep(1)  # 每秒发送一次


@socketio.on('connect')
def handle_connect():
    print("Client connected")


if __name__ == '__main__':
    # 启动后台任务
    socketio.start_background_task(generate_data)
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
