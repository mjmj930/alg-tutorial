// src/store/index.ts
import { createPinia } from 'pinia';
import { useUeStore } from './modules/ueModule';
import { useBsStore } from './modules/bsModule';

const pinia = createPinia();

// Pinia 自动管理模块，无需手动注册
export default pinia;
export { useUeStore, useBsStore };