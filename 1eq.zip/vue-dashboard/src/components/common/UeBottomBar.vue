<template>
  <div class="charts-container">
    <ULLineChart class="chart" />
    <DLLineChart class="chart" />
    <DLRSRPChart class="chart" />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import ULLineChart from '@/components/charts/ULThroughputChart.vue';
import DLLineChart from '@/components/charts/DLThroughputChart.vue';
import DLRSRPChart from '@/components/charts/DownlinkRSRP.vue';

export default defineComponent({
  name: 'UserDashboardCharts',
  components: {
    ULLineChart,
    DLLineChart,
    DLRSRPChart,
  },
});
</script>

<style scoped>
.charts-container {
  display: flex;
  flex-direction: row;
  gap: 20px;  
  height: 100%;
  /* 将容器整体向上移动 */
  margin-top: -20px; /* 调整此值，根据需要向上移动 */
} 
.chart {
  flex: 1; /* 让每个图表占用均等的空间 */
  max-height: 250px; /* 限制图表的最大高度 */
  overflow: hidden; /* 防止图表溢出 */
}
</style>