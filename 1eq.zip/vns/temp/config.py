# config.py

class Config:
    # UE 服务器网络配置
    UE_SERVER_HOST = "127.0.0.1"
    UE_SERVER_PORT = 3000

    # Socket 超时与缓冲区
    SOCKET_TIMEOUT = 5
    RECV_BUF_SIZE = 4096

    # 日志配置（可结合 logging 模块）
    LOG_FILE = "app.log"
