<!-- src/components/layouts/Layout.vue -->
<template>
  <div class="dashboard-layout">
    <!-- 地图作为底层 -->
    <div class="map-container">
      <!-- 示例使用谷歌地图，您可以根据需求替换为其他地图服务 -->
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434508616!2d144.96305771531873!3d-37.81410797975159!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf5779b57f7bd3b0!2sFederation%20Square!5e0!3m2!1sen!2sau&maptype=satellite"
        width="100%"
        height="100%"
        style="border:0;"
        allowfullscreen=""
        loading="lazy"
      ></iframe>
    </div>

    <!-- 左侧栏 -->
    <div class="sidebar">
      <Header />
      <div class="sidebar-content">
        <slot name="sidebar"></slot>
      </div>
    </div>

    <!-- 底部栏 -->
    <div class="bottom-bar">
      <slot name="bottom-bar"></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
export default defineComponent({
  name: 'DashboardLayout',
  components: {
    // Header,
  },
});
</script>

<style scoped>
.dashboard-layout {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}

/* 地图容器 */
.map-container {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 0;
}

/* 左侧栏 */
.sidebar {
  position: absolute;
  top: 0;
  left: 0;
  width: 25%;
  height: 100%;
  background: rgba(0, 0, 50, 0.6); /* 蓝黑色半透明 */
  color: #fff;
  display: flex;
  flex-direction: column;
  z-index: 1;
}

.sidebar-content {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  box-sizing: border-box;
}

/* 底部栏 */
.bottom-bar {
  position: absolute;
  bottom: 0;
  left: 25%;
  width: 75%;
  height: 30%;
  background: rgba(0, 0, 50, 0.6); /* 蓝黑色半透明 */
  color: #fff;
  padding: 20px;
  box-sizing: border-box;
  z-index: 1;
}
</style>
