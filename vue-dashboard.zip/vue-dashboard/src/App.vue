<template>
    <div class="min-h-screen bg-gray-50">
      <el-header class="bg-white shadow-sm">
        <div class="text-xl font-bold text-primary flex items-center h-full px-6">
          <el-icon><DataAnalysis /></el-icon>
          <span class="ml-2">数据可视化平台</span>
        </div>
      </el-header>
      
      <el-main class="p-6">
        <router-view />
      </el-main>
      
      <el-footer class="text-center text-gray-500 text-sm py-4">
        © 2025 数据可视化平台
      </el-footer>
    </div>
  </template>
  
  <script setup lang="ts">
  import { DataAnalysis } from '@element-plus/icons-vue'
  </script>
  
  <style scoped>
  :deep(.el-header) {
    height: 60px !important;
  }
  
  :deep(.el-main) {
    min-height: calc(100vh - 120px) !important;
  }
  
  :deep(.el-footer) {
    height: 60px !important;
  }
  </style>    