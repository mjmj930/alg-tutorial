<template>
    <div id="chart" ref="chartRef" class="chart"></div>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, onBeforeUnmount, ref } from "vue";
  import * as echarts from "echarts";
  
  export default defineComponent({
    name: "ULThroughputChart",
    setup() {
      const chartRef = ref<HTMLDivElement | null>(null); // 图表 DOM 容器
      let chartInstance: echarts.ECharts | null = null; // 图表实例
      let interval: number | undefined;
  
      // 初始数据
      const initialData = {
        categories: [] as string[], // 横轴时间数据
        data1: [] as number[], // 数据1
      };
  
      // 初始化图表
      const initChart = () => {
        if (!chartRef.value) return;
  
        // 创建图表实例
        chartInstance = echarts.init(chartRef.value);
  
        // 配置选项
        const option: echarts.EChartsOption = {
          title: {
            text: "下行 Throughput",
            left: "left",
            textStyle: {
              color: "#EEEEEE", // 设置标题颜色
              fontSize: 18, // 设置标题字体大小
              fontWeight: "bold", // 设置标题字体粗细
            },
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "cross",
              label: {
                backgroundColor: "#6a7985",
              },
            },
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true,
          },
          xAxis: {
            type: "category",
            boundaryGap: false,
            data: initialData.categories,
            axisLine: {
              lineStyle: {
                color: "#e6e7ed", // 设置横坐标轴线的颜色
              },
            },
            axisLabel: {
              color: "#e6e7ed", // 设置横坐标轴文字的颜色
            },
          },
          yAxis: {
            type: "value",
            min: 3000, // 设置纵坐标的最小值
            max: 10000, // 设置纵坐标的最大值
            axisLine: {
              lineStyle: {
                color: "#e6e7ed", // 设置纵坐标轴线的颜色
              },
            },
            axisLabel: {
              color: "#e6e7ed", // 设置纵坐标轴文字的颜色
            },
            splitLine: {
              show: false, // 隐藏网格线
            },
          },
          series: [
            {
              name: "ULThroughput",
              type: "line",
              smooth: true,
              areaStyle: {
                color: "#c60ac9", // 设置面积颜色
              },
              emphasis: {
                focus: "series",
              },
              data: initialData.data1,
              itemStyle: {
                color: "rgba(84, 112, 198, 0.3)", // 设置线条颜色
              },
            },
          ],
        };
  
        // 设置图表选项
        chartInstance.setOption(option);
  
        // 动态更新数据
        interval = window.setInterval(() => {
          updateData();
        }, 1000);
  
        // 窗口大小变化时自适应
        window.addEventListener("resize", resizeChart);
      };
  
      // 更新图表数据
      const updateData = () => {
        const now = new Date();
        const timeString = `${now.getHours().toString().padStart(2, "0")}:${now
          .getMinutes()
          .toString()
          .padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;
  
        // 随机生成 6000 左右的值
        const newData1 = Math.floor(7000 + Math.random() * 1000 - 500); // 6000 ± 500 的值
  
        // 更新初始数据
        initialData.categories.push(timeString);
        initialData.data1.push(newData1);
  
        // 保持最多显示 10 个点
        if (initialData.categories.length > 10) {
          initialData.categories.shift();
          initialData.data1.shift();
        }
  
        // 更新图表
        chartInstance?.setOption({
          xAxis: {
            data: [...initialData.categories], // 确保传递新的时间数据
          },
          series: [
            {
              data: [...initialData.data1], // 确保传递新的数据
            },
          ],
        });
      };
  
      // 图表响应式调整大小
      const resizeChart = () => {
        chartInstance?.resize();
      };
  
      // 销毁图表
      const destroyChart = () => {
        if (chartInstance) {
          chartInstance.dispose();
          chartInstance = null;
        }
        if (interval) {
          clearInterval(interval);
        }
        window.removeEventListener("resize", resizeChart);
      };
  
      // 挂载和卸载生命周期
      onMounted(() => {
        initChart();
      });
  
      onBeforeUnmount(() => {
        destroyChart();
      });
  
      return {
        chartRef,
      };
    },
  });
  </script>
  
  <style scoped>
  .chart {
    width: 100%;
    max-width: 800px;
    height: 400px;
    margin: 0 auto;
  }
  </style>