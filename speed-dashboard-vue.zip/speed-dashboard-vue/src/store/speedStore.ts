import { defineStore } from 'pinia'

export const useSpeedStore = defineStore('speed', {
  state: () => ({
    uploadSpeed: 0,
    downloadSpeed: 0,
    currentMode: 'upload' as 'upload' | 'download'
  }),
  getters: {
    currentSpeed: (state) => 
      state.currentMode === 'upload' ? state.uploadSpeed : state.downloadSpeed,
    currentLabel: (state) => 
      state.currentMode === 'upload' ? '上行吞吐量' : '下行吞吐量',
    currentColor: (state) => 
      state.currentMode === 'upload' ? '#00f2ff' : '#ff00f2',
    maxSpeed: (state) => 
      state.currentMode === 'upload' ? 100 : 200
  },
  actions: {
    updateSpeeds() {
      this.uploadSpeed = Math.floor(Math.random() * 80 + 20)
      this.downloadSpeed = Math.floor(Math.random() * 160 + 40)
    },
    switchMode() {
      this.currentMode = this.currentMode === 'upload' ? 'download' : 'upload'
    }
  }
})    