<template>
  <div class="app-container">
    <router-view />
  </div>
</template>

<script lang="ts" setup>
// 应用根组件
</script>

<style>
.app-container {
  font-family: 'Inter', sans-serif;
  min-height: 100vh;
}
</style>  