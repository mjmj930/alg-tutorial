<template>
  <div 
    class="device-card bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-5 cursor-pointer border-l-4"
    :class="{'border-blue-500': device.status === 'online', 'border-red-500': device.status === 'offline'}"
    @click="$emit('click')"
  >
    <div class="flex justify-between items-start mb-4">
      <h3 class="text-lg font-semibold">{{ device.name }}</h3>
      <span 
        class="px-3 py-1 rounded-full text-xs font-medium"
        :class="{'bg-green-100 text-green-800': device.status === 'online', 'bg-red-100 text-red-800': device.status === 'offline'}"
      >
        {{ device.status }}
      </span>
    </div>
    
    <div class="space-y-3">
      <div class="flex justify-between">
        <span class="text-gray-500 text-sm">IP地址</span>
        <span class="font-medium">{{ device.ip }}</span>
      </div>
      <div class="flex justify-between">
        <span class="text-gray-500 text-sm">网络流量</span>
        <span class="font-medium">{{ device.traffic }} MB/s</span>
      </div>
      <div class="flex justify-between">
        <span class="text-gray-500 text-sm">响应时间</span>
        <span class="font-medium">{{ device.responseTime }} ms</span>
      </div>
    </div>
    
    <div class="mt-4">
      <div class="w-full bg-gray-200 rounded-full h-2">
        <div 
          class="bg-blue-600 h-2 rounded-full"
          :style="{ width: `${device.cpuUsage}%` }"
        ></div>
      </div>
      <div class="flex justify-between text-xs mt-1">
        <span>CPU使用率</span>
        <span>{{ device.cpuUsage }}%</span>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
defineProps<{
  device: {
    id: string
    name: string
    ip: string
    status: 'online' | 'offline'
    traffic: number
    responseTime: number
    cpuUsage: number
  }
}>()

defineEmits(['click'])
</script>  