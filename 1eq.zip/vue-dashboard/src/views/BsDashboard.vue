<!-- src/views/BsDashboard/BsDashboard.vue -->
<template>
  <DashboardLayout>
    <!-- 左侧栏内容 -->
    <template #sidebar>
      <BsSidebar />
    </template>

    <!-- 底部栏内容 -->
    <template #bottom-bar>
      <BsDashboardCharts />
    </template>

    <!-- 右上部分地图已在 DashboardLayout 中定义，无需在此处重复 -->
  </DashboardLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import DashboardLayout from '@/components/layouts/Layout.vue';
import BsSidebar from '@/components/common/BsSideBar.vue';
import BsDashboardCharts from '@/components/common/BsBottomBar.vue';

export default defineComponent({
  name: 'BsDashboard',
  components: {
    DashboardLayout,
    BsSidebar,
    BsDashboardCharts,
  },
});
</script>

<style scoped>
/* 根据需要添加特定样式 */
</style>
