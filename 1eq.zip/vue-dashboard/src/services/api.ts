// src/services/api.ts
import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

export const getUserData = () => apiClient.get('/ue-data');
export const getBsData = () => apiClient.get('/bs-data');
// 其他 API 调用可以根据需求添加