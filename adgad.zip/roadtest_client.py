import socket
import struct
import threading
import time
import json
from collections import deque
from typing import Dict, Callable, Optional
from msg_builder import build_message, build_msg_metric1


class RoadTestClient:
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None
        self.running = False

        # 消息处理
        self.recv_buffer = bytearray()
        self.handlers: Dict[int, Callable] = {}
        self.send_queue = deque()
        self.send_lock = threading.Lock()

        # 注册默认处理器
        self.register_handler(0x1002, self._handle_handshake)
        self.register_handler(0x2002, self._handle_heartbeat)
        self.register_handler(0x4001, self._handle_roadtest_data)

    # ----------------- 连接管理 -----------------
    def connect(self):
        """建立TCP连接"""
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))
        self.running = True

        # 启动线程
        threading.Thread(target=self._recv_loop, daemon=True).start()
        threading.Thread(target=self._send_loop, daemon=True).start()
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()

    def register_handler(self, msgid: int, handler: Callable):
        """注册消息处理器"""
        self.handlers[msgid] = handler

    # ----------------- 消息收发核心 -----------------
    def send(self, message: bytes):
        """发送已构建的比特流（线程安全）"""
        try:
            with self.send_lock:
                self.send_queue.append(message)
        except Exception as e:
            print(f"加入发送队列失败: {e}")

    def _send_loop(self):
        """发送线程"""
        while self.running:
            if self.send_queue:
                with self.send_lock:
                    msg = self.send_queue.popleft()
                try:
                    self.sock.sendall(msg)
                except (BrokenPipeError, ConnectionResetError):
                    self._reconnect()
            time.sleep(0.001)

    def _recv_loop(self):
        """接收线程（处理粘包）"""
        while self.running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    break
                self.recv_buffer.extend(data)

                # 处理所有完整消息
                while len(self.recv_buffer) >= 2:
                    # 解析消息头
                    magic, total_len = struct.unpack_from('!BB', self.recv_buffer)

                    # 校验魔数
                    if magic != 0xAB:
                        print(f"非法魔数 0x{magic:02X}，清空缓冲区")
                        self.recv_buffer.clear()
                        break

                    # 检查消息完整性
                    if len(self.recv_buffer) < total_len:
                        break

                    # 提取完整消息
                    raw_msg = bytes(self.recv_buffer[:total_len])
                    self.recv_buffer = self.recv_buffer[total_len:]

                    # 解析MsgID
                    msgid = struct.unpack_from('!I', raw_msg, 2)[0]

                    # 动态解析消息体
                    if msgid in self.handlers:
                        body_data = raw_msg[6:total_len]  # 头部2字节 + MsgID4字节
                        parsed = self._parse_message(msgid, body_data)
                        self._dispatch(msgid, parsed)
                    else:
                        print(f"未知消息类型: 0x{msgid:04X}")

            except Exception as e:
                print(f"接收错误: {e}")
                break

    def _parse_message(self, msgid: int, body_data: bytes):
        """动态解析消息体"""
        if msgid == 0x4001:  # 自定义消息 metric1
            return {
                "value1": struct.unpack_from('!f', body_data, 0)[0],
                "value2": struct.unpack_from('!I', body_data, 4)[0]
            }
        else:
            # 默认使用通用解析逻辑
            struct_cls = MESSAGE_BODY_STRUCTS.get(msgid)
            if struct_cls:
                return struct_cls.parse(body_data)
            return None

    # ----------------- 消息处理 -----------------
    def _dispatch(self, msgid: int, parsed):
        """分发消息到处理器"""
        if handler := self.handlers.get(msgid):
            try:
                # 转换为字典并生成JSON
                data_dict = parsed_to_dict(parsed)
                json_data = json.dumps({
                    "msgid": f"0x{msgid:04X}",
                    "data": data_dict
                }, indent=2)
                handler(json_data)
            except Exception as e:
                print(f"处理消息失败: {e}")

    def _handle_handshake(self, json_data: str):
        """处理握手响应"""
        print(f"握手响应: {json_data}")

    def _handle_heartbeat(self, json_data: str):
        """处理心跳响应"""
        print(f"心跳确认: {json_data}")

    def _handle_roadtest_data(self, json_data: str):
        """处理路测数据"""
        print(f"路测数据: {json_data}")

    # ----------------- 其他功能 -----------------
    def _heartbeat_loop(self):
        """定时发送心跳"""
        while self.running:
            self.send(0x2001, {"timestamp": int(time.time())})
            time.sleep(15)

    def _reconnect(self):
        """断线重连"""
        self.running = False
        if self.sock:
            self.sock.close()
        print("尝试重新连接...")
        time.sleep(3)
        self.connect()

    def close(self):
        """关闭连接"""
        self.running = False
        if self.sock:
            self.sock.close()


# ----------------- 工具函数 -----------------
def parsed_to_dict(parsed) -> dict:
    """将Construct对象转换为字典"""
    if isinstance(parsed, dict):
        return {k: parsed_to_dict(v) for k, v in parsed.items()}
    elif isinstance(parsed, list):
        return [parsed_to_dict(item) for item in parsed]
    else:
        return parsed


# ----------------- 使用示例 -----------------
if __name__ == "__main__":
    client = RoadTestClient("127.0.0.1", 9000)
    client.connect()

    # 发送握手请求
    client.send(0x1001, {"version": 0x0100})

    # 发送自定义消息 metric1
    client.send(0x4001, {"value1": 12.34, "value2": 56})

    # 保持主线程运行
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        client.close()